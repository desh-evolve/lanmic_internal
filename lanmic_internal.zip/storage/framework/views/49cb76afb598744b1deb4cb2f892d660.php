<?php $__env->startSection('title', 'Requisition Details'); ?>
<?php $__env->startSection('page-title', 'Requisition Details'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('requisitions.index')); ?>">Requisitions</a></li>
    <li class="breadcrumb-item active"><?php echo e($requisition->requisition_number); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Requisition Information</h3>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Requisition Number:</strong></div>
                    <div class="col-md-8">
                        <span class="badge badge-secondary badge-lg"><?php echo e($requisition->requisition_number); ?></span>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Approve Status:</strong></div>
                    <div class="col-md-8">
                        <?php if($requisition->approve_status === 'pending'): ?>
                            <span class="badge badge-warning">Pending</span>
                        <?php elseif($requisition->approve_status === 'approved'): ?>
                            <span class="badge badge-success">Approved</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Rejected</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Clear Status:</strong></div>
                    <div class="col-md-8">
                        <?php if($requisition->clear_status === 'pending'): ?>
                            <span class="badge badge-warning">Pending</span>
                        <?php elseif($requisition->clear_status === 'cleared'): ?>
                            <span class="badge badge-success">Cleared</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Error</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Requested By:</strong></div>
                    <div class="col-md-8"><?php echo e($requisition->user->name); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Department:</strong></div>
                    <div class="col-md-8">
                        <?php echo e($requisition->department->name ?? '-'); ?>

                        <?php if($requisition->department && $requisition->department->short_code): ?>
                            <span class="badge badge-secondary"><?php echo e($requisition->department->short_code); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if($requisition->subDepartment): ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Sub-Department:</strong></div>
                    <div class="col-md-8">
                        <?php echo e($requisition->subDepartment->name); ?>

                        <?php if($requisition->subDepartment->short_code): ?>
                            <span class="badge badge-secondary"><?php echo e($requisition->subDepartment->short_code); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                <?php if($requisition->division): ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Division:</strong></div>
                    <div class="col-md-8">
                        <?php echo e($requisition->division->name); ?>

                        <?php if($requisition->division->short_code): ?>
                            <span class="badge badge-secondary"><?php echo e($requisition->division->short_code); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                <?php if($requisition->notes): ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Notes:</strong></div>
                    <div class="col-md-8"><?php echo e($requisition->notes); ?></div>
                </div>
                <?php endif; ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Created At:</strong></div>
                    <div class="col-md-8"><?php echo e($requisition->created_at->format('Y-m-d H:i:s')); ?></div>
                </div>
                <?php if($requisition->approve_status !== 'pending'): ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong><?php echo e($requisition->approve_status === 'approved' ? 'Approved' : 'Rejected'); ?> By:</strong></div>
                    <div class="col-md-8"><?php echo e($requisition->approvedBy->name ?? '-'); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4"><strong><?php echo e($requisition->approve_status === 'approved' ? 'Approved' : 'Rejected'); ?> At:</strong></div>
                    <div class="col-md-8"><?php echo e($requisition->approved_at ? $requisition->approved_at->format('Y-m-d H:i:s') : '-'); ?></div>
                </div>
                <?php endif; ?>
                <?php if($requisition->approve_status === 'rejected' && $requisition->rejection_reason): ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Rejection Reason:</strong></div>
                    <div class="col-md-8">
                        <div class="alert alert-danger"><?php echo e($requisition->rejection_reason); ?></div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Requisition Items</h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Item Code</th>
                            <th>Item Name</th>
                            <th>Location</th>
                            <th>Category</th>
                            <th>Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $requisition->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><strong><?php echo e($item->item_code); ?></strong></td>
                            <td>
                                <?php echo e($item->item_name); ?>

                                <?php if($item->specifications): ?>
                                    <br><small class="text-muted"><?php echo e($item->specifications); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item->location_name ?? '-'); ?></td>
                            <td><?php echo e($item->item_category ?? '-'); ?></td>
                            <td><?php echo e($item->quantity); ?> <?php echo e($item->unit); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card-footer">
            <a href="<?php echo e(route('requisitions.index')); ?>" class="btn btn-default">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Summary</h3>
            </div>
            <div class="card-body">
                <div class="info-box bg-light">
                    <div class="info-box-content">
                        <span class="info-box-text">Total Items</span>
                        <span class="info-box-number"><?php echo e($requisition->items->count()); ?></span>
                    </div>
                </div>
                <div class="info-box bg-light">
                    <div class="info-box-content">
                        <span class="info-box-text">Total Quantity</span>
                        <span class="info-box-number"><?php echo e($requisition->items->sum('quantity')); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\requisitions\show.blade.php ENDPATH**/ ?>