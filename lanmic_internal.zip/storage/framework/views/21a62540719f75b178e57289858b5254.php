<?php $__env->startSection('title', 'Requisition Summary Report'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .stat-card {
        border-left: 4px solid;
        transition: transform 0.2s;
    }
    .stat-card:hover {
        transform: translateY(-2px);
    }
    .stat-card.primary { border-left-color: #007bff; }
    .stat-card.success { border-left-color: #28a745; }
    .stat-card.warning { border-left-color: #ffc107; }
    .stat-card.danger { border-left-color: #dc3545; }
    .stat-card.info { border-left-color: #17a2b8; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-0">Requisition Summary Report</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('reports.index')); ?>">Reports</a></li>
                            <li class="breadcrumb-item active">Requisition Summary</li>
                        </ol>
                    </nav>
                </div>
                <div>
                    <button class="btn btn-success" onclick="exportToExcel()">
                        <i class="fas fa-file-excel"></i> Export Excel
                    </button>
                    <button class="btn btn-secondary" onclick="window.print()">
                        <i class="fas fa-print"></i> Print
                    </button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 col-sm-6 mb-3">
            <div class="card stat-card primary h-100">
                <div class="card-body">
                    <div class="text-muted small text-uppercase font-weight-bold">Total Requisitions</div>
                    <div class="h2 font-weight-bold mb-0"><?php echo e(number_format($statistics['total_requisitions'])); ?></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 col-sm-6 mb-3">
            <div class="card stat-card info h-100">
                <div class="card-body">
                    <div class="text-muted small text-uppercase font-weight-bold">Total Items</div>
                    <div class="h2 font-weight-bold mb-0"><?php echo e(number_format($statistics['total_items'])); ?></div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
            <div class="card stat-card warning h-100">
                <div class="card-body">
                    <div class="text-muted small text-uppercase font-weight-bold">Pending</div>
                    <div class="h2 font-weight-bold mb-0"><?php echo e(number_format($statistics['pending'])); ?></div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
            <div class="card stat-card success h-100">
                <div class="card-body">
                    <div class="text-muted small text-uppercase font-weight-bold">Approved</div>
                    <div class="h2 font-weight-bold mb-0"><?php echo e(number_format($statistics['approved'])); ?></div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
            <div class="card stat-card danger h-100">
                <div class="card-body">
                    <div class="text-muted small text-uppercase font-weight-bold">Rejected</div>
                    <div class="h2 font-weight-bold mb-0"><?php echo e(number_format($statistics['rejected'])); ?></div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-filter"></i> Filters</h5>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('reports.requisition-summary')); ?>">
                <div class="row">
                    <div class="col-md-2">
                        <label class="form-label">Date From</label>
                        <input type="date" name="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Date To</label>
                        <input type="date" name="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Status</label>
                        <select name="approve_status" class="form-control">
                            <option value="">All Status</option>
                            <option value="pending" <?php echo e(request('approve_status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="approved" <?php echo e(request('approve_status') == 'approved' ? 'selected' : ''); ?>>Approved</option>
                            <option value="rejected" <?php echo e(request('approve_status') == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Department</label>
                        <select name="department_id" class="form-control">
                            <option value="">All Departments</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>" <?php echo e(request('department_id') == $department->id ? 'selected' : ''); ?>>
                                    <?php echo e($department->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">User</label>
                        <select name="user_id" class="form-control">
                            <option value="">All Users</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e(request('user_id') == $user->id ? 'selected' : ''); ?>>
                                    <?php echo e($user->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2">
                            <i class="fas fa-search"></i> Filter
                        </button>
                        <a href="<?php echo e(route('reports.requisition-summary')); ?>" class="btn btn-secondary">
                            <i class="fas fa-redo"></i> Reset
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-table"></i> Requisition Details</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover" id="reportTable">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Requisition No</th>
                            <th>Date</th>
                            <th>User</th>
                            <th>Department</th>
                            <th>Items Count</th>
                            <th>Status</th>
                            <th>Approved By</th>
                            <th>Approved Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $requisitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $requisition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($requisitions->firstItem() + $index); ?></td>
                                <td>
                                    <a href="<?php echo e(route('requisitions.show', $requisition->id)); ?>">
                                        <?php echo e($requisition->requisition_number ?? 'REQ-' . str_pad($requisition->id, 6, '0', STR_PAD_LEFT)); ?>

                                    </a>
                                </td>
                                <td><?php echo e($requisition->created_at->format('d M Y')); ?></td>
                                <td><?php echo e($requisition->user->name ?? 'N/A'); ?></td>
                                <td><?php echo e($requisition->department->name ?? 'N/A'); ?></td>
                                <td class="text-center"><?php echo e($requisition->items->count()); ?></td>
                                <td>
                                    <?php if($requisition->approve_status == 'pending'): ?>
                                        <span class="badge bg-warning text-dark">Pending</span>
                                    <?php elseif($requisition->approve_status == 'approved'): ?>
                                        <span class="badge bg-success">Approved</span>
                                    <?php elseif($requisition->approve_status == 'rejected'): ?>
                                        <span class="badge bg-danger">Rejected</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e(ucfirst($requisition->approve_status)); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($requisition->approvedBy->name ?? '-'); ?></td>
                                <td><?php echo e($requisition->approved_at ? \Carbon\Carbon::parse($requisition->approved_at)->format('d M Y') : '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center py-4">
                                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">No requisitions found</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <div class="d-flex justify-content-between align-items-center mt-3">
                <div>
                    Showing <?php echo e($requisitions->firstItem() ?? 0); ?> to <?php echo e($requisitions->lastItem() ?? 0); ?> of <?php echo e($requisitions->total()); ?> entries
                </div>
                <?php echo e($requisitions->appends(request()->query())->links()); ?>

            </div>
        </div>
    </div>
</div>

<script>
    function exportToExcel() {
        // Get current URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        urlParams.set('export', 'excel');
        
        // Redirect with export parameter
        window.location.href = window.location.pathname + '?' + urlParams.toString();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\reports\requisition-summary.blade.php ENDPATH**/ ?>