<?php $__env->startSection('title', 'Requisition Approvals'); ?>
<?php $__env->startSection('page-title', 'Requisition Approvals'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item active">Requisition Approvals</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="row mb-3">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?php echo e(\App\Models\Requisition::pending()->count()); ?></h3>
                        <p>Pending Requisitions</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?php echo e(\App\Models\Requisition::approved()->count()); ?></h3>
                        <p>Approved Requisitions</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-check"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?php echo e(\App\Models\Requisition::rejected()->count()); ?></h3>
                        <p>Rejected Requisitions</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-times"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?php echo e(\App\Models\Requisition::count()); ?></h3>
                        <p>Total Requisitions</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">All Requisitions</h3>
                <div class="card-tools">
                    <form method="GET" action="<?php echo e(route('admin.requisitions.index')); ?>" class="form-inline">
                        <div class="input-group input-group-sm" style="width: 350px;">
                            <select name="approve_status" class="form-control form-control-sm">
                                <option value="">All Approve Status</option>
                                <option value="pending" <?php echo e(request('status') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="approved" <?php echo e(request('status') === 'approved' ? 'selected' : ''); ?>>Approved</option>
                                <option value="rejected" <?php echo e(request('status') === 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                            </select>
                            <select name="clear_status" class="form-control form-control-sm">
                                <option value="">All Clear Status</option>
                                <option value="pending" <?php echo e(request('status') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="cleared" <?php echo e(request('status') === 'cleared' ? 'selected' : ''); ?>>Cleared</option>
                            </select>
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-default">
                                    <i class="fas fa-filter"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                    <thead>
                        <tr>
                            <th>Requisition #</th>
                            <th>Requested By</th>
                            <th>Department</th>
                            <th>Items</th>
                            <th>Approve Status</th>
                            <th>Clear Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $requisitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><strong><?php echo e($requisition->requisition_number); ?></strong></td>
                            <td><?php echo e($requisition->user->name); ?></td>
                            <td>
                                <?php echo e($requisition->department->name ?? '-'); ?>

                                <?php if($requisition->subDepartment): ?>
                                    <br><small class="text-muted"><?php echo e($requisition->subDepartment->name); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge badge-info"><?php echo e($requisition->items->count()); ?> items</span>
                            </td>
                            <td>
                                <?php if($requisition->approve_status === 'pending'): ?>
                                    <span class="badge badge-warning">Pending</span>
                                <?php elseif($requisition->approve_status === 'approved'): ?>
                                    <span class="badge badge-success">Approved</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Rejected</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($requisition->approve_status !== 'rejected'): ?>
                                    <?php if($requisition->clear_status === 'pending'): ?>
                                        <span class="badge badge-warning">Pending</span>
                                    <?php elseif($requisition->clear_status === 'cleared'): ?>
                                        <span class="badge badge-success">Cleared</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Error</span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($requisition->created_at->format('Y-m-d')); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.requisitions.show', $requisition->id)); ?>" class="btn btn-info btn-sm">
                                    <i class="fas fa-eye"></i> View
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center">No requisitions found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer clearfix">
                <?php echo e($requisitions->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\requisitions\index.blade.php ENDPATH**/ ?>