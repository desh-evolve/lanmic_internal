<?php $__env->startSection('title', 'Purchase Order Details'); ?>
<?php $__env->startSection('page-title', 'Purchase Order Details'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.purchase-orders.index')); ?>">Purchase Orders</a></li>
    <li class="breadcrumb-item active">Details</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-file-invoice"></i> Purchase Order Item Details
                </h3>
                <div class="card-tools">
                    <a href="<?php echo e(route('admin.purchase-orders.index')); ?>" class="btn btn-secondary btn-sm">
                        <i class="fas fa-arrow-left"></i> Back to List
                    </a>
                </div>
            </div>
            <div class="card-body">
                <!-- Status Badge -->
                <div class="row mb-3">
                    <div class="col-12">
                        <?php if($poItem->status === 'pending'): ?>
                            <span class="badge badge-warning badge-lg">
                                <i class="fas fa-clock"></i> Pending
                            </span>
                        <?php else: ?>
                            <span class="badge badge-success badge-lg">
                                <i class="fas fa-check"></i> Cleared
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Item Information -->
                <h5 class="border-bottom pb-2 mb-3">Item Information</h5>
                <div class="row mb-4">
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <th width="150">Item Code:</th>
                                <td><strong><?php echo e($poItem->item_code); ?></strong></td>
                            </tr>
                            <tr>
                                <th>Item Name:</th>
                                <td><?php echo e($poItem->item_name); ?></td>
                            </tr>
                            <tr>
                                <th>Category:</th>
                                <td><?php echo e($poItem->item_category ?? '-'); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <th width="150">Quantity:</th>
                                <td><strong><?php echo e($poItem->quantity); ?> <?php echo e($poItem->unit); ?></strong></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <!-- Requisition Information -->
                <h5 class="border-bottom pb-2 mb-3">Requisition Information</h5>
                <div class="row mb-4">
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <th width="150">Requisition #:</th>
                                <td><strong><?php echo e($poItem->requisition->requisition_number); ?></strong></td>
                            </tr>
                            <tr>
                                <th>Requested By:</th>
                                <td><?php echo e($poItem->requisition->user->name); ?></td>
                            </tr>
                            <tr>
                                <th>Department:</th>
                                <td><?php echo e($poItem->requisition->department->name ?? '-'); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <th width="150">Request Date:</th>
                                <td><?php echo e($poItem->requisition->created_at->format('Y-m-d H:i')); ?></td>
                            </tr>
                            <tr>
                                <th>Status:</th>
                                <td>
                                    <span class="badge badge-info"><?php echo e(ucfirst($poItem->requisition->status)); ?></span>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>

                <!-- Clearing Information (if cleared) -->
                <?php if($poItem->status === 'cleared'): ?>
                <h5 class="border-bottom pb-2 mb-3">Clearing Information</h5>
                <div class="row mb-4">
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <th width="150">Cleared By:</th>
                                <td><?php echo e($poItem->clearedBy->name ?? '-'); ?></td>
                            </tr>
                            <tr>
                                <th>Cleared At:</th>
                                <td><?php echo e($poItem->cleared_at ? $poItem->cleared_at->format('Y-m-d H:i:s') : '-'); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Additional Notes -->
                <?php if($poItem->notes): ?>
                <h5 class="border-bottom pb-2 mb-3">Notes</h5>
                <div class="row mb-4">
                    <div class="col-12">
                        <p><?php echo e($poItem->notes); ?></p>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Action Buttons -->
                <div class="row mt-4">
                    <div class="col-12">
                        <?php if($poItem->status === 'pending'): ?>
                            <button type="button" class="btn btn-success" onclick="clearPurchaseOrder()">
                                <i class="fas fa-check"></i> Clear Purchase Order
                            </button>
                        <?php endif; ?>
                        <a href="<?php echo e(route('admin.purchase-orders.index')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back to List
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if($poItem->status === 'pending'): ?>
<form id="clearForm" method="POST" action="<?php echo e(route('admin.purchase-orders.clear')); ?>" style="display: none;">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="po_item_ids[]" value="<?php echo e($poItem->id); ?>">
</form>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function clearPurchaseOrder() {
    if (confirm('Are you sure you want to clear this purchase order item?')) {
        document.getElementById('clearForm').submit();
    }
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\purchase-orders\show.blade.php ENDPATH**/ ?>