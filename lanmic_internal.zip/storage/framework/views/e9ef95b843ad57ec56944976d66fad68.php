<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(url('/home')); ?>" class="brand-link">
        <span class="brand-text font-weight-light">LANMIC Internal</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <i class="fas fa-user-circle fa-2x text-white"></i>
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo e(Auth::user()->name); ?></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

                <!-- Dashboard -->
                <?php if(Auth::user()->hasPermission('view-dashboard')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(url('/home')); ?>" class="nav-link <?php echo e(request()->is('home') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <?php endif; ?>

                <!-- REQUISITIONS Dropdown -->
                <?php if(Auth::user()->hasAnyPermission(['view-requisitions', 'create-requisitions'])): ?>
                <li class="nav-item has-treeview <?php echo e(request()->is('requisitions*') && !request()->is('admin/requisitions*') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link <?php echo e(request()->is('requisitions*') && !request()->is('admin/requisitions*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-file-alt"></i>
                        <p>
                            Requisitions
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <?php if(Auth::user()->hasPermission('view-requisitions')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('requisitions.index')); ?>" class="nav-link <?php echo e(request()->is('requisitions/index') || request()->is('requisitions/*') && !request()->is('requisitions/create*') && !request()->is('admin/requisitions*') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>My Requisitions</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::user()->hasPermission('create-requisitions')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('requisitions.create')); ?>" class="nav-link <?php echo e(request()->is('requisitions/create*') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Create Requisition</p>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>

                <!-- RETURNS Dropdown -->
                <?php if(Auth::user()->hasAnyPermission(['view-returns', 'create-returns'])): ?>
                <li class="nav-item has-treeview <?php echo e(request()->is('returns*') && !request()->is('admin/returns*') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link <?php echo e(request()->is('returns*') && !request()->is('admin/returns*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-undo-alt"></i>
                        <p>
                            Returns
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <?php if(Auth::user()->hasPermission('view-returns')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('returns.index')); ?>" class="nav-link <?php echo e(request()->is('returns') && !request()->is('returns/create*') && !request()->is('admin/returns*') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>My Returns</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::user()->hasPermission('create-returns')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('returns.create')); ?>" class="nav-link <?php echo e(request()->is('returns/create*') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Create Return</p>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::user()->hasAnyPermission(['approve-requisitions', 'issue-requisitions', 'approve-returns', 'view-purchase-orders', 'view-reports', 'view-users', 'view-roles', 'view-permissions', 'view-departments', 'view-sub-departments', 'view-divisions'])): ?>

                <li class="nav-header">ADMINISTRATION</li>

                <!-- Requisition Approvals -->
                <?php if(Auth::user()->hasAnyPermission(['approve-requisitions', 'issue-requisitions'])): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.requisitions.index')); ?>" class="nav-link <?php echo e(request()->is('admin/requisitions*') ? 'active' : ''); ?>">
                        <i class="fas fa-file-signature nav-icon"></i>
                        <p>
                            Requisition Approvals
                            <?php
                                $pendingCount = \App\Models\Requisition::pending()->count();
                            ?>
                            <?php if($pendingCount > 0): ?>
                                <span class="badge badge-warning right"><?php echo e($pendingCount); ?></span>
                            <?php endif; ?>
                        </p>
                    </a>
                </li>
                <?php endif; ?>

                <!-- Return Approvals -->
                <?php if(Auth::user()->hasPermission('approve-returns')): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.returns.index')); ?>" class="nav-link <?php echo e(request()->is('admin/returns*') ? 'active' : ''); ?>">
                        <i class="fas fa-exchange-alt nav-icon"></i>
                        <p>
                            Return Approvals
                            <?php
                                $pendingReturns = \App\Models\ReturnModel::pending()->count();
                            ?>
                            <?php if($pendingReturns > 0): ?>
                                <span class="badge badge-warning right"><?php echo e($pendingReturns); ?></span>
                            <?php endif; ?>
                        </p>
                    </a>
                </li>
                <?php endif; ?>

                <!-- PURCHASE ORDERS Dropdown -->
                <?php if(Auth::user()->hasPermission('view-purchase-orders')): ?>
                <li class="nav-item <?php echo e(request()->is('admin/purchase-orders*') ? 'menu-open' : ''); ?>">
                    <a href="<?php echo e(route('admin.purchase-orders.index', ['status' => 'pending'])); ?>" class="nav-link <?php echo e(request()->is('admin/purchase-orders*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-shopping-cart"></i>
                        <p>
                            Purchase Orders
                            <?php
                                $pendingPOCount = \App\Models\PurchaseOrderItem::where('status', 'pending')->count();
                            ?>
                            <?php if($pendingPOCount > 0): ?>
                                <span class="badge badge-warning right"><?php echo e($pendingPOCount); ?></span>
                            <?php endif; ?>
                        </p>
                    </a>
                </li>
                <?php endif; ?>

                <!-- REPORTS Dropdown -->
                <?php if(Auth::user()->hasPermission('view-reports')): ?>
                <li class="nav-item has-treeview <?php echo e(request()->is('admin/reports*') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link <?php echo e(request()->is('admin/reports*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-chart-bar"></i>
                        <p>
                            Reports
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('reports.index')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.index') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Reports Dashboard</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('reports.requisition-summary')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.requisition-summary') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Requisition Summary</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('reports.item-requisition')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.item-requisition') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Item Requisition</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('reports.issued-items')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.issued-items') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Issued Items</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('reports.purchase-order')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.purchase-order') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Purchase Orders</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('reports.returns-summary')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.returns-summary') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Returns Summary</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('reports.grn')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.grn') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>GRN Report</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('reports.scrap')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.scrap') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Scrap Report</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('reports.department-activity')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.department-activity') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Department Activity</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('reports.user-activity')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.user-activity') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>User Activity</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('reports.monthly-summary')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.monthly-summary') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Monthly Summary</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if(Auth::user()->hasAnyPermission(['view-users', 'view-roles', 'view-permissions', 'view-departments', 'view-sub-departments', 'view-divisions'])): ?>
                <li class="nav-header">MASTER FILES</li>
                <?php endif; ?>

                <!-- AUTHENTICATION Dropdown -->
                <?php if(Auth::user()->hasAnyPermission(['view-users', 'view-roles', 'view-permissions'])): ?>
                <li class="nav-item has-treeview <?php echo e(request()->is('admin/users*') || request()->is('admin/roles*') || request()->is('admin/permissions*') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link <?php echo e(request()->is('admin/users*') || request()->is('admin/roles*') || request()->is('admin/permissions*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-users"></i>
                        <p>
                            Authentication
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <?php if(Auth::user()->hasPermission('view-users')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('users.index')); ?>" class="nav-link <?php echo e(request()->is('admin/users*') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Users</p>
                            </a>
                        </li>
                        <?php endif; ?>

                        <?php if(Auth::user()->hasPermission('view-roles')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('roles.index')); ?>" class="nav-link <?php echo e(request()->is('admin/roles*') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Roles</p>
                            </a>
                        </li>
                        <?php endif; ?>

                        
                    </ul>
                </li>
                <?php endif; ?>

                <!-- ORGANIZATION Dropdown -->
                <?php if(Auth::user()->hasAnyPermission(['view-departments', 'view-sub-departments', 'view-divisions'])): ?>
                <li class="nav-item has-treeview <?php echo e(request()->is('admin/departments*') || request()->is('admin/sub-departments*') || request()->is('admin/divisions*') ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link <?php echo e(request()->is('admin/departments*') || request()->is('admin/sub-departments*') || request()->is('admin/divisions*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-sitemap"></i>
                        <p>
                            Organization
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <?php if(Auth::user()->hasPermission('view-departments')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('departments.index')); ?>" class="nav-link <?php echo e(request()->is('admin/departments*') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Departments</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::user()->hasPermission('view-sub-departments')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('sub-departments.index')); ?>" class="nav-link <?php echo e(request()->is('admin/sub-departments*') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Sub-Departments</p>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::user()->hasPermission('view-divisions')): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('divisions.index')); ?>" class="nav-link <?php echo e(request()->is('admin/divisions*') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Divisions</p>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>

                <?php endif; ?>
            </ul>
        </nav>
    </div>
</aside><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\layouts\partials\sidebar.blade.php ENDPATH**/ ?>