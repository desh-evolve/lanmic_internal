<?php $__env->startSection('title', 'Division Details'); ?>
<?php $__env->startSection('page-title', 'Division Details'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('divisions.index')); ?>">Divisions</a></li>
    <li class="breadcrumb-item active">Details</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header" style="background-color: rgb(192, 189, 189)">
                    <h3 class="card-title">Division Information</h3>
                    <div class="card-tools">
                        <a href="<?php echo e(route('divisions.edit', $division->id)); ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-3"><strong>ID:</strong></div>
                        <div class="col-md-9"><?php echo e($division->id); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-3"><strong>Name:</strong></div>
                        <div class="col-md-9"><?php echo e($division->name); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-3"><strong>Short Code:</strong></div>
                        <div class="col-md-9">
                            <?php if($division->short_code): ?>
                                <span class="badge badge-secondary"><?php echo e($division->short_code); ?></span>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-3"><strong>Description:</strong></div>
                        <div class="col-md-9"><?php echo e($division->description ?? '-'); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-3"><strong>Status:</strong></div>
                        <div class="col-md-9">
                            <?php if($division->status == 'active'): ?>
                                <span class="badge badge-success">Active</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Inactive</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-3"><strong>Created At:</strong></div>
                        <div class="col-md-9"><?php echo e($division->created_at->format('Y-m-d H:i:s')); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-3"><strong>Updated At:</strong></div>
                        <div class="col-md-9"><?php echo e($division->updated_at->format('Y-m-d H:i:s')); ?></div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header" style="background-color: rgb(192, 189, 189)">
                    <h3 class="card-title">Sub-Departments (<?php echo e($division->subDepartments->count()); ?>)</h3>
                </div>
                

                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $division->subDepartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subDepartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <div class="p-3 mb-2 border rounded bg-white shadow-sm">

                            <!-- Sub Department Title -->
                            <div class="mb-4 d-flex justify-content-between" style="height:26px;">
                                <div>
                                    <strong class="h6"><?php echo e($subDepartment->name); ?></strong>
                                    <?php if($subDepartment->short_code): ?>
                                        <span class="badge badge-secondary"><?php echo e($subDepartment->short_code); ?></span>
                                    <?php endif; ?>

                                    <?php if($subDepartment->description): ?>
                                        <p class="text-muted mt-1 mb-1">
                                            <?php echo e(Str::limit($subDepartment->description, 120)); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>

                                <a href="<?php echo e(route('sub-departments.show', $subDepartment->id)); ?>" class="btn btn-xs btn-info">
                                    <i class="fas fa-eye"></i> View
                                </a>
                            </div>

                            <!-- Divisions Section -->
                            <?php if($subDepartment->departments->count()): ?>
                                <div class="mt-3 ml-4"> 
                                    <strong class="text-primary d-block mb-2">Divisions:</strong>

                                    <?php $__currentLoopData = $subDepartment->departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mb-2 pl-3">
                                    <strong><?php echo e($department->name); ?></strong>

                                    <?php if($department->short_code): ?>
                                    <span class="badge badge-secondary"><?php echo e($department->short_code); ?></span>
                                    <?php endif; ?>

                                    <br>
                                    <small class="text-muted">
                                    <?php echo e($department->description ?? '-'); ?>

                                    </small>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            <?php else: ?>
                                <p class="text-muted ml-4">No department assigned</p>
                            <?php endif; ?>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted">No sub-departments assigned to this department</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card-footer d-flex justify-content-end"
                style="position: sticky; bottom: 0; background: white; z-index: 10;">
                <a href="<?php echo e(route('divisions.index')); ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to List
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\divisions\show.blade.php ENDPATH**/ ?>