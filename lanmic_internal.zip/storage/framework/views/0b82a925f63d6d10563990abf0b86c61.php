<?php $__env->startSection('title', 'Purchase Orders'); ?>
<?php $__env->startSection('page-title', 'Purchase Orders Management'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item active">Purchase Orders</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="row mb-3">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?php echo e($statistics['pending_count']); ?></h3>
                        <p>Pending PO Items</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?php echo e($statistics['pending_quantity']); ?></h3>
                        <p>Pending Quantity</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-boxes"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?php echo e($statistics['cleared_count']); ?></h3>
                        <p>Cleared PO Items</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-check"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e($status === 'pending' ? 'active' : ''); ?>" 
                           href="<?php echo e(route('admin.purchase-orders.index', ['status' => 'pending', 'group_by' => $groupBy])); ?>">
                            <i class="fas fa-clock"></i> Pending 
                            <span class="badge badge-warning"><?php echo e($statistics['pending_count']); ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e($status === 'cleared' ? 'active' : ''); ?>" 
                           href="<?php echo e(route('admin.purchase-orders.index', ['status' => 'cleared', 'group_by' => $groupBy])); ?>">
                            <i class="fas fa-check"></i> Cleared 
                            <span class="badge badge-success"><?php echo e($statistics['cleared_count']); ?></span>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <!-- Filters and Group By -->
                <form method="GET" action="<?php echo e(route('admin.purchase-orders.index')); ?>" class="mb-3">
                    <input type="hidden" name="status" value="<?php echo e($status); ?>">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Group By</label>
                                <select name="group_by" class="form-control" onchange="this.form.submit()">
                                    <option value="item" <?php echo e($groupBy === 'item' ? 'selected' : ''); ?>>Item</option>
                                    <option value="requisition" <?php echo e($groupBy === 'requisition' ? 'selected' : ''); ?>>Requisition</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Date From</label>
                                <input type="date" name="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Date To</label>
                                <input type="date" name="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>Item Code</label>
                                <input type="text" name="item_code" class="form-control" value="<?php echo e(request('item_code')); ?>" placeholder="Search by code">
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Apply Filters
                    </button>
                    <a href="<?php echo e(route('admin.purchase-orders.index', ['status' => $status, 'group_by' => $groupBy])); ?>" class="btn btn-secondary">
                        <i class="fas fa-redo"></i> Reset
                    </a>
                </form>

                <?php if($groupBy === 'requisition'): ?>
                    <?php echo $__env->make('admin.purchase-orders.partials.grouped-by-requisition', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php else: ?>
                    <?php echo $__env->make('admin.purchase-orders.partials.grouped-by-item', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\purchase-orders\index.blade.php ENDPATH**/ ?>