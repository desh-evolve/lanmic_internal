<footer class="main-footer">
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="#">LANMIC</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.0
    </div>
</footer><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\layouts\partials\footer.blade.php ENDPATH**/ ?>