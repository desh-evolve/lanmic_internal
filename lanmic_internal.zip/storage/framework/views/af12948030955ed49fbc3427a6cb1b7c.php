<?php $__env->startSection('title', 'Return Details'); ?>
<?php $__env->startSection('page-title', 'Return Details - Admin View'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.returns.index')); ?>">Return Approvals</a></li>
    <li class="breadcrumb-item active">#<?php echo e($return->id); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
        </div>
        <?php endif; ?>

        <?php if(session('warning')): ?>
        <div class="alert alert-warning alert-dismissible fade show">
            <?php echo e(session('warning')); ?>

            <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Return Information</h3>
                <div class="card-tools">
                    <?php if($return->status === 'pending'): ?>
                        <a href="<?php echo e(route('admin.returns.approve-items', $return->id)); ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-check-double"></i> Process Items
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if($return->status === 'pending'): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Action Required:</strong> This return is pending approval. Process items individually.
                </div>
                <?php elseif($return->status === 'cleared'): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <strong>Cleared:</strong> All items have been processed for this return.
                </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <th width="40%">Return ID:</th>
                                <td><span class="badge badge-secondary badge-lg">#<?php echo e($return->id); ?></span></td>
                            </tr>
                            <tr>
                                <th>Requisition:</th>
                                <td>
                                    <a href="<?php echo e(route('requisitions.show', $return->requisition->id)); ?>" target="_blank">
                                        <?php echo e($return->requisition->requisition_number); ?>

                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <th>Department:</th>
                                <td><?php echo e($return->requisition->department->name ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Returned By:</th>
                                <td><?php echo e($return->returnedBy->name); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <th width="40%">Returned At:</th>
                                <td><?php echo e($return->returned_at->format('Y-m-d H:i:s')); ?></td>
                            </tr>
                            <tr>
                                <th>Status:</th>
                                <td>
                                    <?php if($return->status === 'pending'): ?>
                                        <span class="badge badge-warning badge-lg">Pending</span>
                                    <?php else: ?>
                                        <span class="badge badge-success badge-lg">Cleared</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Total Items:</th>
                                <td><span class="badge badge-info"><?php echo e($return->items->count()); ?></span></td>
                            </tr>
                            <tr>
                                <th>Total Quantity:</th>
                                <td><span class="badge badge-primary"><?php echo e($return->total_quantity); ?></span></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Return Items</h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Item</th>
                            <th>Type</th>
                            <th>Location</th>
                            <th>Quantity</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $return->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php echo e($item->approve_status === 'approved' ? 'table-success' : ($item->approve_status === 'rejected' ? 'table-danger' : ($item->approve_status === 'partial' ? 'table-warning' : ''))); ?>">
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <strong><?php echo e($item->item_name); ?></strong>
                                <br><small class="text-muted"><?php echo e($item->item_code); ?></small>
                                <?php if($item->notes): ?>
                                    <br><small><i class="fas fa-info-circle"></i> <?php echo e($item->notes); ?></small>
                                <?php endif; ?>
                                <?php if($item->admin_note): ?>
                                    <br><small class="text-primary"><i class="fas fa-comment"></i> Admin: <?php echo e($item->admin_note); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo e($item->type_badge); ?>">
                                    <?php echo e($item->getTypeLabel()); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge badge-info"><?php echo e($item->location_code); ?></span><br>
                                <small><?php echo e($item->location_name); ?></small>
                            </td>
                            <td>
                                <span class="badge badge-primary"><?php echo e($item->quantity); ?> <?php echo e($item->unit); ?></span>
                            </td>
                            <td>
                                <?php if($item->approve_status === 'pending'): ?>
                                    <span class="badge badge-warning">Pending</span>
                                <?php elseif($item->approve_status === 'approved'): ?>
                                    <span class="badge badge-success">Approved</span>
                                <?php elseif($item->approve_status === 'rejected'): ?>
                                    <span class="badge badge-danger">Rejected</span>
                                <?php elseif($item->approve_status === 'partial'): ?>
                                    <span class="badge badge-warning">Partial</span>
                                <?php endif; ?>
                                <?php if($item->approved_at): ?>
                                    <br><small class="text-muted"><?php echo e($item->approved_at->format('Y-m-d H:i')); ?></small>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if($return->grnItems->count() > 0): ?>
        <div class="card card-success">
            <div class="card-header">
                <h3 class="card-title">GRN Items (Posted to SAGE)</h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Item</th>
                            <th>Location</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total Price</th>
                            <th>SAGE Ref</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $return->grnItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $grn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <strong><?php echo e($grn->item_name); ?></strong>
                                <br><small class="text-muted"><?php echo e($grn->item_code); ?></small>
                            </td>
                            <td>
                                <span class="badge badge-info"><?php echo e($grn->location_code); ?></span>
                            </td>
                            <td><span class="badge badge-success"><?php echo e($grn->grn_quantity); ?> <?php echo e($grn->unit); ?></span></td>
                            <td>Rs. <?php echo e(number_format($grn->unit_price, 2)); ?></td>
                            <td>Rs. <?php echo e(number_format($grn->total_price, 2)); ?></td>
                            <td>
                                <?php if($grn->reference_number_1): ?>
                                    <small><?php echo e($grn->reference_number_1); ?></small>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <?php if($return->scrapItems->count() > 0): ?>
        <div class="card card-danger">
            <div class="card-header">
                <h3 class="card-title">Scrap Items (DB Only)</h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Item</th>
                            <th>Location</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $return->scrapItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $scrap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <strong><?php echo e($scrap->item_name); ?></strong>
                                <br><small class="text-muted"><?php echo e($scrap->item_code); ?></small>
                            </td>
                            <td>
                                <span class="badge badge-info"><?php echo e($scrap->location_code); ?></span>
                            </td>
                            <td><span class="badge badge-danger"><?php echo e($scrap->scrap_quantity); ?> <?php echo e($scrap->unit); ?></span></td>
                            <td>Rs. <?php echo e(number_format($scrap->unit_price, 2)); ?></td>
                            <td>Rs. <?php echo e(number_format($scrap->total_price, 2)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <div class="card-footer">
            <a href="<?php echo e(route('admin.returns.index')); ?>" class="btn btn-default">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
            <?php if($return->status === 'pending' && $return->items->where('approve_status', 'pending')->count() > 0): ?>
                <a href="<?php echo e(route('admin.returns.approve-items', $return->id)); ?>" class="btn btn-primary">
                    <i class="fas fa-check-double"></i> Process Items
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Summary</h3>
            </div>
            <div class="card-body">
                <div class="info-box bg-light">
                    <div class="info-box-content">
                        <span class="info-box-text">Total Items</span>
                        <span class="info-box-number"><?php echo e($return->items->count()); ?></span>
                    </div>
                </div>
                <div class="info-box bg-warning">
                    <div class="info-box-content">
                        <span class="info-box-text">Pending</span>
                        <span class="info-box-number"><?php echo e($return->items->where('approve_status', 'pending')->count()); ?></span>
                    </div>
                </div>
                <div class="info-box bg-success">
                    <div class="info-box-content">
                        <span class="info-box-text">Approved</span>
                        <span class="info-box-number"><?php echo e($return->items->where('approve_status', 'approved')->count()); ?></span>
                    </div>
                </div>
                <div class="info-box bg-danger">
                    <div class="info-box-content">
                        <span class="info-box-text">Rejected</span>
                        <span class="info-box-number"><?php echo e($return->items->where('approve_status', 'rejected')->count()); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Requester Info</h3>
            </div>
            <div class="card-body">
                <strong><i class="fas fa-user"></i> Name</strong>
                <p class="text-muted"><?php echo e($return->returnedBy->name); ?></p>
                <hr>
                <strong><i class="fas fa-envelope"></i> Email</strong>
                <p class="text-muted"><?php echo e($return->returnedBy->email); ?></p>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Original Requisition</h3>
            </div>
            <div class="card-body">
                <strong>Number:</strong>
                <p>
                    <a href="<?php echo e(route('requisitions.show', $return->requisition->id)); ?>" target="_blank">
                        <?php echo e($return->requisition->requisition_number); ?>

                    </a>
                </p>
                <hr>
                <strong>Department:</strong>
                <p><?php echo e($return->requisition->department->name); ?></p>
                <hr>
                <strong>Created:</strong>
                <p><?php echo e($return->requisition->created_at->format('Y-m-d')); ?></p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\returns\show.blade.php ENDPATH**/ ?>