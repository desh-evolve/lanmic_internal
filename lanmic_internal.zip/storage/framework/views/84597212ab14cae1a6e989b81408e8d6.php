<?php $__env->startSection('title', 'Department Activity Report'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .progress-bar-animated {
        animation: progress-bar-stripes 1s linear infinite;
    }
    .dept-card {
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .dept-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 0.5rem 1rem rgba(0,0,0,.15);
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-0">Department Activity Report</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('reports.index')); ?>">Reports</a></li>
                            <li class="breadcrumb-item active">Department Activity</li>
                        </ol>
                    </nav>
                </div>
                <div>
                    <button class="btn btn-success" onclick="exportToExcel()">
                        <i class="fas fa-file-excel"></i> Export Excel
                    </button>
                    <button class="btn btn-secondary" onclick="window.print()">
                        <i class="fas fa-print"></i> Print
                    </button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-filter"></i> Filters</h5>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('reports.department-activity')); ?>">
                <div class="row">
                    <div class="col-md-4">
                        <label class="form-label">Date From</label>
                        <input type="date" name="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Date To</label>
                        <input type="date" name="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>">
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2">
                            <i class="fas fa-search"></i> Filter
                        </button>
                        <a href="<?php echo e(route('reports.department-activity')); ?>" class="btn btn-secondary">
                            <i class="fas fa-redo"></i> Reset
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="row mb-4">
        <?php
            $maxRequisitions = collect($reportData)->max('total_requisitions') ?: 1;
            $colors = ['primary', 'success', 'info', 'warning', 'danger', 'secondary', 'dark'];
        ?>
        
        <?php $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-4 col-lg-6 mb-4">
                <div class="card dept-card h-100">
                    <div class="card-header bg-<?php echo e($colors[$index % count($colors)]); ?> text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-building me-2"></i><?php echo e($data['department']->name); ?>

                        </h5>
                    </div>
                    <div class="card-body">
                        
                        <div class="mb-3">
                            <div class="d-flex justify-content-between mb-1">
                                <span>Total Requisitions</span>
                                <strong><?php echo e(number_format($data['total_requisitions'])); ?></strong>
                            </div>
                            <div class="progress" style="height: 10px;">
                                <div class="progress-bar bg-<?php echo e($colors[$index % count($colors)]); ?>" 
                                     style="width: <?php echo e(($data['total_requisitions'] / $maxRequisitions) * 100); ?>%">
                                </div>
                            </div>
                        </div>

                        
                        <div class="row text-center mb-3">
                            <div class="col-4">
                                <div class="border rounded p-2">
                                    <div class="h5 mb-0 text-warning"><?php echo e($data['pending_requisitions']); ?></div>
                                    <small class="text-muted">Pending</small>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="border rounded p-2">
                                    <div class="h5 mb-0 text-success"><?php echo e($data['approved_requisitions']); ?></div>
                                    <small class="text-muted">Approved</small>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="border rounded p-2">
                                    <div class="h5 mb-0 text-danger"><?php echo e($data['rejected_requisitions']); ?></div>
                                    <small class="text-muted">Rejected</small>
                                </div>
                            </div>
                        </div>

                        
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>Total Items Requested</span>
                                <strong><?php echo e(number_format($data['total_items'])); ?></strong>
                            </li>
                        </ul>
                    </div>
                    <div class="card-footer bg-light">
                        <a href="<?php echo e(route('reports.requisition-summary', ['department_id' => $data['department']->id])); ?>" 
                           class="btn btn-sm btn-outline-<?php echo e($colors[$index % count($colors)]); ?>">
                            <i class="fas fa-eye"></i> View Details
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-table"></i> Department Summary Table</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Department</th>
                            <th class="text-center">Total Requisitions</th>
                            <th class="text-center">Pending</th>
                            <th class="text-center">Approved</th>
                            <th class="text-center">Rejected</th>
                            <th class="text-end">Total Items</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $grandItems = 0; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $grandItems += $data['total_items'];
                            ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td>
                                    <i class="fas fa-building me-1 text-muted"></i>
                                    <?php echo e($data['department']->name); ?>

                                </td>
                                <td class="text-center">
                                    <span class="badge bg-primary rounded-pill"><?php echo e($data['total_requisitions']); ?></span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-warning text-dark rounded-pill"><?php echo e($data['pending_requisitions']); ?></span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-success rounded-pill"><?php echo e($data['approved_requisitions']); ?></span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-danger rounded-pill"><?php echo e($data['rejected_requisitions']); ?></span>
                                </td>
                                <td class="text-end"><?php echo e(number_format($data['total_items'])); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('reports.requisition-summary', ['department_id' => $data['department']->id])); ?>"
                                       class="btn btn-sm btn-info" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4">
                                    <i class="fas fa-building fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">No department data found</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot class="table-secondary">
                        <tr>
                            <th colspan="6" class="text-end">Grand Total:</th>
                            <th class="text-end"><?php echo e(number_format($grandItems)); ?></th>
                            <th></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    function exportToExcel() {
        // Get current URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        urlParams.set('export', 'excel');
        
        // Redirect with export parameter
        window.location.href = window.location.pathname + '?' + urlParams.toString();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\reports\department-activity.blade.php ENDPATH**/ ?>