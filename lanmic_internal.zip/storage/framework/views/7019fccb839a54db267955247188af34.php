<?php $__env->startSection('title', 'Return Approvals'); ?>
<?php $__env->startSection('page-title', 'Return Approvals'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item active">Return Approvals</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="row mb-3">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?php echo e(\App\Models\ReturnModel::pending()->count()); ?></h3>
                        <p>Pending Returns</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?php echo e(\App\Models\ReturnModel::cleared()->count()); ?></h3>
                        <p>Cleared Returns</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-check"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?php echo e(\App\Models\GrnItem::where('status', 'active')->count()); ?></h3>
                        <p>GRN Items</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-box"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?php echo e(\App\Models\ScrapItem::where('status', 'active')->count()); ?></h3>
                        <p>Scrap Items</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-trash"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">All Returns</h3>
                <div class="card-tools">
                    <form method="GET" action="<?php echo e(route('admin.returns.index')); ?>" class="form-inline">
                        <div class="input-group input-group-sm">
                            <select name="status" class="form-control form-control-sm">
                                <option value="">All Status</option>
                                <option value="pending" <?php echo e(request('status') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="cleared" <?php echo e(request('status') === 'cleared' ? 'selected' : ''); ?>>Cleared</option>
                            </select>
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-default">
                                    <i class="fas fa-filter"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Returned By</th>
                            <th>Returned At</th>
                            <th>Items</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $return): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><strong>#<?php echo e($return->id); ?></strong></td>
                            <td><?php echo e($return->returnedBy->name); ?></td>
                            <td><?php echo e($return->returned_at->format('Y-m-d H:i')); ?></td>
                            <td>
                                <span class="badge badge-info"><?php echo e($return->items->count()); ?> items</span>
                                <br>
                                <small>
                                    <span class="badge badge-warning"><?php echo e($return->items->where('approve_status', 'pending')->count()); ?> pending</span>
                                    <span class="badge badge-success"><?php echo e($return->items->where('approve_status', 'approved')->count()); ?> approved</span>
                                    <span class="badge badge-danger"><?php echo e($return->items->where('approve_status', 'rejected')->count()); ?> rejected</span>
                                </small>
                            </td>
                            <td>
                                <?php if($return->status === 'pending'): ?>
                                    <span class="badge badge-warning">Pending</span>
                                <?php elseif($return->status === 'cleared'): ?>
                                    <span class="badge badge-success">Cleared</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.returns.show', $return->id)); ?>" class="btn btn-info btn-sm">
                                    <i class="fas fa-eye"></i> View
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">No returns found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer clearfix">
                <?php echo e($returns->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\returns\index.blade.php ENDPATH**/ ?>