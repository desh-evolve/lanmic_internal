<?php $__empty_1 = true; $__currentLoopData = $poItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemCode => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php
        $firstItem = $items->first();
        $totalQuantity = $items->sum('quantity');
        $totalValue = $items->sum('total_price');
        $requisitionsCount = $items->unique('requisition_id')->count();
    ?>
    <div class="card mb-3">
        <div class="card-header bg-light">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h5 class="mb-0">
                        Item Code: <strong><?php echo e($itemCode); ?></strong>
                    </h5>
                    <small class="text-muted">
                        <?php echo e($firstItem->item_name); ?> | 
                        Category: <?php echo e($firstItem->item_category ?? '-'); ?> | 
                        From <?php echo e($requisitionsCount); ?> requisition(s)
                    </small>
                </div>
                <div class="col-md-6 text-right">
                    <span class="badge badge-info"><?php echo e($items->count()); ?> orders</span>
                    <span class="badge badge-primary">Total Qty: <?php echo e($totalQuantity); ?></span>
                    <span class="badge badge-success">Value: Rs.<?php echo e(number_format($totalValue, 2)); ?></span>
                    <?php if($status === 'pending'): ?>
                        <button type="button" class="btn btn-success btn-sm ml-2" 
                                onclick="clearItemPO('<?php echo e($itemCode); ?>')">
                            <i class="fas fa-check"></i> Clear All
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <table class="table table-sm table-hover mb-0">
                <thead class="thead-light">
                    <tr>
                        <?php if($status === 'pending'): ?>
                        <th width="50">
                            <input type="checkbox" class="select-all-item" data-item="<?php echo e($itemCode); ?>">
                        </th>
                        <?php endif; ?>
                        <th>Requisition #</th>
                        <th>Requested By</th>
                        <th>Department</th>
                        <th>Date</th>
                        <th>Location</th>
                        <th>Quantity</th>
                        <?php if($status === 'cleared'): ?>
                        <th>Cleared By</th>
                        <th>Cleared At</th>
                        <?php endif; ?>
                        <?php if($status === 'pending'): ?>
                        <th>Action</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if($status === 'pending'): ?>
                        <td>
                            <input type="checkbox" class="po-item-checkbox" value="<?php echo e($item->id); ?>" data-item="<?php echo e($itemCode); ?>">
                        </td>
                        <?php endif; ?>
                        <td>
                            <strong><?php echo e($item->requisition->requisition_number); ?></strong>
                        </td>
                        <td><?php echo e($item->requisition->user->name); ?></td>
                        <td><?php echo e($item->requisition->department->name ?? '-'); ?></td>
                        <td><?php echo e($item->requisition->created_at->format('Y-m-d')); ?></td>
                        <td><?php echo e($item->location_name ?? '-'); ?></td>
                        <td><?php echo e($item->quantity); ?> <?php echo e($item->unit); ?></td>
                        <?php if($status === 'cleared'): ?>
                        <td><?php echo e($item->clearedBy->name ?? '-'); ?></td>
                        <td><?php echo e($item->cleared_at ? $item->cleared_at->format('Y-m-d H:i') : '-'); ?></td>
                        <?php endif; ?>
                        <?php if($status === 'pending'): ?>
                        <td>
                            <button type="button" class="btn btn-success btn-xs" onclick="clearSinglePO(<?php echo e($item->id); ?>)">
                                <i class="fas fa-check"></i> Clear
                            </button>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i> No purchase orders found.
    </div>
<?php endif; ?>

<?php if($status === 'pending' && $poItems->count() > 0): ?>
<div class="fixed-bottom bg-white border-top p-3 shadow" style="z-index: 1000;">
    <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-md-8">
                <span id="selectedCount" class="badge badge-primary">0</span> items selected
            </div>
            <div class="col-md-4 text-right">
                <button type="button" class="btn btn-success" id="bulkClearBtn" disabled onclick="bulkClearSelected()">
                    <i class="fas fa-check-double"></i> Clear Selected
                </button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Select all for item
$('.select-all-item').change(function() {
    const itemCode = $(this).data('item');
    const isChecked = $(this).prop('checked');
    $(`.po-item-checkbox[data-item="${itemCode}"]`).prop('checked', isChecked);
    updateBulkClearButton();
});

// Individual checkbox
$('.po-item-checkbox').change(function() {
    updateBulkClearButton();
});

function updateBulkClearButton() {
    const selectedCount = $('.po-item-checkbox:checked').length;
    $('#selectedCount').text(selectedCount);
    $('#bulkClearBtn').prop('disabled', selectedCount === 0);
}

function clearSinglePO(poItemId) {
    if (confirm('Are you sure you want to clear this purchase order item?')) {
        submitClearForm([poItemId]);
    }
}

function clearItemPO(itemCode) {
    if (confirm('Are you sure you want to clear all purchase order items for this item?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '<?php echo e(route("admin.purchase-orders.bulk-clear")); ?>';
        
        const csrfToken = document.createElement('input');
        csrfToken.type = 'hidden';
        csrfToken.name = '_token';
        csrfToken.value = '<?php echo e(csrf_token()); ?>';
        form.appendChild(csrfToken);
        
        const actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = 'action';
        actionInput.value = 'clear_item';
        form.appendChild(actionInput);
        
        const itemInput = document.createElement('input');
        itemInput.type = 'hidden';
        itemInput.name = 'item_code';
        itemInput.value = itemCode;
        form.appendChild(itemInput);
        
        document.body.appendChild(form);
        form.submit();
    }
}

function bulkClearSelected() {
    const selectedIds = $('.po-item-checkbox:checked').map(function() {
        return $(this).val();
    }).get();
    
    if (selectedIds.length === 0) {
        alert('Please select at least one item');
        return;
    }
    
    if (confirm(`Are you sure you want to clear ${selectedIds.length} purchase order item(s)?`)) {
        submitClearForm(selectedIds);
    }
}

function submitClearForm(poItemIds) {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '<?php echo e(route("admin.purchase-orders.clear")); ?>';
    
    const csrfToken = document.createElement('input');
    csrfToken.type = 'hidden';
    csrfToken.name = '_token';
    csrfToken.value = '<?php echo e(csrf_token()); ?>';
    form.appendChild(csrfToken);
    
    poItemIds.forEach(id => {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'po_item_ids[]';
        input.value = id;
        form.appendChild(input);
    });
    
    document.body.appendChild(form);
    form.submit();
}
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\purchase-orders\partials\grouped-by-item.blade.php ENDPATH**/ ?>