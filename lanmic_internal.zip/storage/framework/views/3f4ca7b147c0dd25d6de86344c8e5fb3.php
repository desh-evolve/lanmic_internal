<?php $__env->startSection('title', 'Sub-Department Details'); ?>
<?php $__env->startSection('page-title', 'Sub-Department Details'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('sub-departments.index')); ?>">Sub-Departments</a></li>
    <li class="breadcrumb-item active">Details</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header" style="background-color: rgb(192, 189, 189)">
                <h3 class="card-title">Sub-Department Information</h3>
                <div class="card-tools">
                    <a href="<?php echo e(route('sub-departments.edit', $subDepartment->id)); ?>" class="btn btn-warning btn-sm">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-3"><strong>ID:</strong></div>
                    <div class="col-md-9"><?php echo e($subDepartment->id); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-3"><strong>Name:</strong></div>
                    <div class="col-md-9"><?php echo e($subDepartment->name); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-3"><strong>Short Code:</strong></div>
                    <div class="col-md-9">
                        <?php if($subDepartment->short_code): ?>
                            <span class="badge badge-secondary"><?php echo e($subDepartment->short_code); ?></span>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-3"><strong>Description:</strong></div>
                    <div class="col-md-9"><?php echo e($subDepartment->description ?? '-'); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-3"><strong>Status:</strong></div>
                    <div class="col-md-9">
                        <?php if($subDepartment->status == 'active'): ?>
                            <span class="badge badge-success">Active</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Inactive</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-3"><strong>Created At:</strong></div>
                    <div class="col-md-9"><?php echo e($subDepartment->created_at->format('Y-m-d H:i:s')); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-3"><strong>Updated At:</strong></div>
                    <div class="col-md-9"><?php echo e($subDepartment->updated_at->format('Y-m-d H:i:s')); ?></div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header" style="background-color: rgb(192, 189, 189)">
                <h3 class="card-title">Parent Departments (<?php echo e($subDepartment->departments->count()); ?>)</h3>
            </div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $subDepartment->departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="d-flex justify-content-between align-items-center mb-2 p-2 border-bottom">
                        <div>
                            <strong><?php echo e($department->name); ?></strong>
                            <?php if($department->short_code): ?>
                                <span class="badge badge-secondary"><?php echo e($department->short_code); ?></span>
                            <?php endif; ?>
                            <?php if($department->description): ?>
                                <br>
                                <small class="text-muted"><?php echo e(Str::limit($department->description, 100)); ?></small>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo e(route('departments.show', $department->id)); ?>" class="btn btn-sm btn-info">
                            <i class="fas fa-eye"></i> View
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">Not assigned to any departments</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header" style="background-color: rgb(192, 189, 189)">
                <h3 class="card-title">Divisions (<?php echo e($subDepartment->divisions->count()); ?>)</h3>
            </div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $subDepartment->divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="d-flex justify-content-between align-items-center mb-2 p-2 border-bottom">
                        <div>
                            <strong><?php echo e($division->name); ?></strong>
                            <?php if($division->short_code): ?>
                                <span class="badge badge-secondary"><?php echo e($division->short_code); ?></span>
                            <?php endif; ?>
                            <?php if($division->description): ?>
                                <br>
                                <small class="text-muted"><?php echo e(Str::limit($division->description, 100)); ?></small>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo e(route('divisions.show', $division->id)); ?>" class="btn btn-sm btn-info">
                            <i class="fas fa-eye"></i> View
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">No divisions assigned to this sub-department</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="card-footer d-flex justify-content-end"
                style="position: sticky; bottom: 0; background: white; z-index: 10;">
                <a href="<?php echo e(route('sub-departments.index')); ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to List
                </a>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\sub-departments\show.blade.php ENDPATH**/ ?>