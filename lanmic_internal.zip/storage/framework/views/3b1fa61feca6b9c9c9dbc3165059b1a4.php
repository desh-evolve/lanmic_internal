<?php $__env->startSection('title', 'My Requisitions'); ?>
<?php $__env->startSection('page-title', 'My Requisitions'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item active">My Requisitions</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">My Requisitions</h3>
                <div class="card-tools">
                    <a href="<?php echo e(route('requisitions.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Create New Requisition
                    </a>
                </div>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                    <thead>
                        <tr>
                            <th>Requisition #</th>
                            <th>Department</th>
                            <th>Items</th>
                            <th>Approve Status</th>
                            <th>Clear Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $requisitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><strong><?php echo e($requisition->requisition_number); ?></strong></td>
                            <td>
                                <?php echo e($requisition->department->name ?? '-'); ?>

                                <?php if($requisition->subDepartment): ?>
                                    <br><small class="text-muted"><?php echo e($requisition->subDepartment->name); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge badge-info"><?php echo e($requisition->items->count()); ?> items</span>
                            </td>
                            <td>
                                <?php if($requisition->approve_status === 'pending'): ?>
                                    <span class="badge badge-warning">Pending</span>
                                <?php elseif($requisition->approve_status === 'approved'): ?>
                                    <span class="badge badge-success">Approved</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Rejected</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($requisition->clear_status === 'pending'): ?>
                                    <span class="badge badge-warning">Pending</span>
                                <?php elseif($requisition->clear_status === 'cleared'): ?>
                                    <span class="badge badge-success">Cleared</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Error</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($requisition->created_at->format('Y-m-d')); ?></td>
                            <td>
                                <a href="<?php echo e(route('requisitions.show', $requisition->id)); ?>" class="btn btn-info btn-sm">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php if($requisition->approve_status === 'pending'): ?>
                                
                                <form action="<?php echo e(route('requisitions.destroy', $requisition->id)); ?>" method="POST" style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this requisition?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">No requisitions found. <a href="<?php echo e(route('requisitions.create')); ?>">Create your first requisition</a></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer clearfix">
                <?php echo e($requisitions->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\requisitions\index.blade.php ENDPATH**/ ?>