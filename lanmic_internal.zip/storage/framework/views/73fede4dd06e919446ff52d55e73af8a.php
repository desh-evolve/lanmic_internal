<?php $__env->startSection('title', 'Permission Details'); ?>
<?php $__env->startSection('page-title', 'Permission Details'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('permissions.index')); ?>">Permissions</a></li>
    <li class="breadcrumb-item active">Details</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Permission Information</h3>
                <div class="card-tools">
                    <a href="<?php echo e(route('permissions.edit', $permission->id)); ?>" class="btn btn-warning btn-sm">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-3"><strong>ID:</strong></div>
                    <div class="col-md-9"><?php echo e($permission->id); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-3"><strong>Name:</strong></div>
                    <div class="col-md-9"><span class="badge badge-success badge-lg"><?php echo e($permission->name); ?></span></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-3"><strong>Description:</strong></div>
                    <div class="col-md-9"><?php echo e($permission->description ?? '-'); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-3"><strong>Created At:</strong></div>
                    <div class="col-md-9"><?php echo e($permission->created_at->format('Y-m-d H:i:s')); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-3"><strong>Updated At:</strong></div>
                    <div class="col-md-9"><?php echo e($permission->updated_at->format('Y-m-d H:i:s')); ?></div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Roles with this Permission (<?php echo e($permission->roles->count()); ?>)</h3>
            </div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $permission->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="d-flex justify-content-between align-items-center mb-2 p-2 border-bottom">
                        <div>
                            <strong><?php echo e($role->name); ?></strong>
                            <?php if($role->description): ?>
                                <br>
                                <small class="text-muted"><?php echo e($role->description); ?></small>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo e(route('roles.show', $role->id)); ?>" class="btn btn-sm btn-info">
                            <i class="fas fa-eye"></i> View
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">This permission is not assigned to any roles</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="card-footer">
            <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-default">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\permissions\show.blade.php ENDPATH**/ ?>