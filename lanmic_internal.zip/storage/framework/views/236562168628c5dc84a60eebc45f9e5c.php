<?php $__env->startSection('title', 'Return Details'); ?>
<?php $__env->startSection('page-title', 'Return Details'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('returns.index')); ?>">Returns</a></li>
    <li class="breadcrumb-item active">Details</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Return Information</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <th width="40%">Requisition:</th>
                                <td>
                                    <a href="<?php echo e(route('requisitions.show', $return->requisition->id)); ?>" target="_blank">
                                        <?php echo e($return->requisition->requisition_number); ?>

                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <th>Department:</th>
                                <td><?php echo e($return->requisition->department->name ?? 'N/A'); ?></td>
                            </tr>
                            <?php if($return->requisition->subDepartment): ?>
                            <tr>
                                <th>Sub-Department:</th>
                                <td><?php echo e($return->requisition->subDepartment->name); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <th>Returned By:</th>
                                <td><?php echo e($return->returnedBy->name); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-sm table-borderless">
                            <tr>
                                <th width="40%">Returned At:</th>
                                <td><?php echo e($return->returned_at->format('Y-m-d H:i:s')); ?></td>
                            </tr>
                            <tr>
                                <th>Status:</th>
                                <td>
                                    <?php if($return->status === 'pending'): ?>
                                        <span class="badge badge-warning">Pending Approval</span>
                                    <?php elseif($return->status === 'approved'): ?>
                                        <span class="badge badge-success">Approved</span>
                                    <?php elseif($return->status === 'rejected'): ?>
                                        <span class="badge badge-danger">Rejected</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary"><?php echo e(ucfirst($return->status)); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Total Items:</th>
                                <td><span class="badge badge-info"><?php echo e($return->items->count()); ?></span></td>
                            </tr>
                            <tr>
                                <th>Total Quantity:</th>
                                <td><span class="badge badge-primary"><?php echo e($return->total_quantity); ?></span></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Return Items</h3>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover mb-0">
                        <thead class="thead-light">
                            <tr>
                                <th width="5%">#</th>
                                <th width="10%">Type</th>
                                <th width="10%">Code</th>
                                <th width="20%">Name</th>
                                <th width="10%">Category</th>
                                <th width="15%">Return Location</th>
                                <th width="8%">Qty</th>
                                <th width="7%">Unit</th>
                                <th width="15%">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $return->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo e($item->type_badge); ?>">
                                        <?php echo e($item->getTypeLabel()); ?>

                                    </span>
                                </td>
                                <td><?php echo e($item->item_code); ?></td>
                                <td>
                                    <?php echo e($item->item_name); ?>

                                    <?php if($item->notes): ?>
                                        <br><small class="text-muted"><i class="fas fa-sticky-note"></i> <?php echo e($item->notes); ?></small>
                                    <?php endif; ?>
                                    <?php if($item->admin_note): ?>
                                        <br><small class="text-danger"><i class="fas fa-exclamation-triangle"></i> Admin: <?php echo e($item->admin_note); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->item_category ?? 'N/A'); ?></td>
                                <td>
                                    <span class="badge badge-info"><?php echo e($item->location_code); ?></span><br>
                                    <small><?php echo e($item->location_name); ?></small>
                                </td>
                                <td><span class="badge badge-primary"><?php echo e($item->quantity); ?></span></td>
                                <td><span class="badge badge-secondary"><?php echo e($item->unit); ?></span></td>
                                <td>
                                    <span class="badge badge-<?php echo e($item->status_badge); ?>">
                                        <?php echo e(ucfirst($item->approve_status)); ?>

                                    </span>
                                    <?php if($item->approved_at): ?>
                                        <br><small class="text-muted"><?php echo e($item->approved_at->format('Y-m-d')); ?></small>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php if($return->grnItems->count() > 0): ?>
        <div class="card">
            <div class="card-header bg-success">
                <h3 class="card-title">GRN Items (Good Returns)</h3>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-sm mb-0">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Item Code</th>
                                <th>Item Name</th>
                                <th>Quantity</th>
                                <th>Created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $return->grnItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $grn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($grn->item_code); ?></td>
                                <td><?php echo e($grn->item_name); ?></td>
                                <td><span class="badge badge-success"><?php echo e($grn->grn_quantity); ?></span></td>
                                <td><?php echo e($grn->created_at->format('Y-m-d H:i')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if($return->scrapItems->count() > 0): ?>
        <div class="card">
            <div class="card-header bg-danger">
                <h3 class="card-title">Scrap Items</h3>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-sm mb-0">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Item Code</th>
                                <th>Item Name</th>
                                <th>Quantity</th>
                                <th>Created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $return->scrapItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $scrap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($scrap->item_code); ?></td>
                                <td><?php echo e($scrap->item_name); ?></td>
                                <td><span class="badge badge-danger"><?php echo e($scrap->scrap_quantity); ?></span></td>
                                <td><?php echo e($scrap->created_at->format('Y-m-d H:i')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-footer">
                <a href="<?php echo e(route('returns.index')); ?>" class="btn btn-default">
                    <i class="fas fa-arrow-left"></i> Back to List
                </a>
                
                <?php if($return->status === 'pending'): ?>
                <form action="<?php echo e(route('returns.destroy', $return->id)); ?>" 
                      method="POST" 
                      class="d-inline float-right"
                      onsubmit="return confirm('Are you sure you want to delete this return?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash"></i> Delete Return
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Summary</h3>
            </div>
            <div class="card-body">
                <div class="info-box bg-light">
                    <div class="info-box-content">
                        <span class="info-box-text">Total Items</span>
                        <span class="info-box-number"><?php echo e($return->items->count()); ?></span>
                    </div>
                </div>
                <div class="info-box bg-success">
                    <div class="info-box-content">
                        <span class="info-box-text">Same Condition</span>
                        <span class="info-box-number"><?php echo e($return->same_items_count); ?></span>
                    </div>
                </div>
                <div class="info-box bg-warning">
                    <div class="info-box-content">
                        <span class="info-box-text">Used Items</span>
                        <span class="info-box-number"><?php echo e($return->used_items_count); ?></span>
                    </div>
                </div>
                <div class="info-box bg-info">
                    <div class="info-box-content">
                        <span class="info-box-text">Total Quantity</span>
                        <span class="info-box-number"><?php echo e($return->total_quantity); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Approval Status</h3>
            </div>
            <div class="card-body">
                <?php
                    $pendingCount = $return->items->where('approve_status', 'pending')->count();
                    $approvedCount = $return->items->where('approve_status', 'approved')->count();
                    $rejectedCount = $return->items->where('approve_status', 'rejected')->count();
                ?>
                
                <table class="table table-sm">
                    <tr>
                        <td>Pending:</td>
                        <td class="text-right">
                            <span class="badge badge-warning"><?php echo e($pendingCount); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td>Approved:</td>
                        <td class="text-right">
                            <span class="badge badge-success"><?php echo e($approvedCount); ?></span>
                        </td>
                    </tr>
                    <tr>
                        <td>Rejected:</td>
                        <td class="text-right">
                            <span class="badge badge-danger"><?php echo e($rejectedCount); ?></span>
                        </td>
                    </tr>
                </table>

                <?php if($return->status === 'pending'): ?>
                <div class="alert alert-info mt-3 mb-0">
                    <i class="icon fas fa-info"></i>
                    <small>Your return is pending admin approval.</small>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Original Requisition</h3>
            </div>
            <div class="card-body">
                <table class="table table-sm table-borderless mb-0">
                    <tr>
                        <th>Number:</th>
                        <td>
                            <a href="<?php echo e(route('requisitions.show', $return->requisition->id)); ?>" target="_blank">
                                <?php echo e($return->requisition->requisition_number); ?>

                            </a>
                        </td>
                    </tr>
                    <tr>
                        <th>Department:</th>
                        <td><?php echo e($return->requisition->department->name); ?></td>
                    </tr>
                    <tr>
                        <th>Created:</th>
                        <td><?php echo e($return->requisition->created_at->format('Y-m-d')); ?></td>
                    </tr>
                    <tr>
                        <th>Status:</th>
                        <td>
                            <span class="badge badge-success">
                                <?php echo e(ucfirst($return->requisition->clear_status)); ?>

                            </span>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\returns\show.blade.php ENDPATH**/ ?>