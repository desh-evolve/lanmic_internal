<?php $__env->startSection('title', 'Manage User Permissions'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-0">Manage Permissions for <?php echo e($user->name); ?></h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Users</a></li>
                            <li class="breadcrumb-item active">Permissions</li>
                        </ol>
                    </nav>
                </div>
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Assign Permissions</h5>
                    <small class="text-muted">Add or remove permissions as needed.</small>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('users.permissions.update', $user)); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module => $modulePermissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-4">
                                <h6 class="text-uppercase text-primary border-bottom pb-2">
                                    <i class="fas fa-cube"></i> <?php echo e(ucfirst($module)); ?> Module
                                </h6>
                                <div class="row">
                                    <?php $__currentLoopData = $modulePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $isFromRole = in_array($permission->id, $rolePermissions);
                                            $isDirectPermission = in_array($permission->id, $userPermissions);
                                            $isChecked = $isFromRole || $isDirectPermission;
                                        ?>
                                        <div class="col-md-6 mb-2">
                                            <div class="form-check">
                                                <input
                                                    class="form-check-input"
                                                    type="checkbox"
                                                    name="permissions[]"
                                                    value="<?php echo e($permission->id); ?>"
                                                    id="perm_<?php echo e($permission->id); ?>"
                                                    <?php echo e($isChecked ? 'checked' : ''); ?>>
                                                <label class="form-check-label <?php echo e($isFromRole ? 'text-success fw-bold' : ''); ?>" for="perm_<?php echo e($permission->id); ?>">
                                                    <?php echo e($permission->description); ?>

                                                    <?php if($isFromRole): ?>
                                                        <small class="badge bg-success ms-1">Role</small>
                                                    <?php endif; ?>
                                                    <?php if($isDirectPermission): ?>
                                                        <small class="badge bg-primary ms-1">Direct</small>
                                                    <?php endif; ?>
                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Update Permissions
                            </button>
                            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">User Information</h5>
                </div>
                <div class="card-body">
                    <p><strong>Name:</strong> <?php echo e($user->name); ?></p>
                    <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                    <p><strong>Roles:</strong>
                        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-info"><?php echo e($role->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div>
            </div>

            <div class="card mt-3">
                <div class="card-header bg-secondary text-white">
                    <h5 class="mb-0">Legend</h5>
                </div>
                <div class="card-body">
                    <p class="mb-2"><span class="badge bg-success">Green</span> = From Role (pre-ticked)</p>
                    <p class="mb-0"><span class="badge bg-primary">Blue</span> = Direct Permission</p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\users\user_permission.blade.php ENDPATH**/ ?>