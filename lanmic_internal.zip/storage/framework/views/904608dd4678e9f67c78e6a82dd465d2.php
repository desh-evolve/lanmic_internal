<?php $__env->startSection('title', 'Scrap Report'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-0">Scrap Report</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('reports.index')); ?>">Reports</a></li>
                            <li class="breadcrumb-item active">Scrap</li>
                        </ol>
                    </nav>
                </div>
                <div>
                    <button class="btn btn-success" onclick="exportToExcel()">
                        <i class="fas fa-file-excel"></i> Export Excel
                    </button>
                    <button class="btn btn-secondary" onclick="window.print()">
                        <i class="fas fa-print"></i> Print
                    </button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card bg-dark text-white">
                <div class="card-body text-center">
                    <i class="fas fa-trash-alt fa-2x mb-2"></i>
                    <h3 class="mb-0"><?php echo e(number_format($statistics['total_scrap_items'])); ?></h3>
                    <small>Total Scrap Items</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-danger text-white">
                <div class="card-body text-center">
                    <i class="fas fa-boxes fa-2x mb-2"></i>
                    <h3 class="mb-0"><?php echo e(number_format($statistics['total_quantity'])); ?></h3>
                    <small>Total Quantity Scrapped</small>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-warning text-dark">
                <div class="card-body text-center">
                    <i class="fas fa-dollar-sign fa-2x mb-2"></i>
                    <h3 class="mb-0"><?php echo e(number_format($statistics['total_value'], 2)); ?></h3>
                    <small>Total Value Lost</small>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-dark text-white">
                    <h5 class="mb-0"><i class="fas fa-exclamation-triangle"></i> Top 10 Most Scrapped Items</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th>Rank</th>
                                    <th>Item Code</th>
                                    <th>Item Name</th>
                                    <th class="text-center">Scrap Count</th>
                                    <th class="text-end">Total Quantity</th>
                                    <th class="text-end">Total Value</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $itemStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php if($index == 0): ?>
                                                <span class="badge bg-danger">1</span>
                                            <?php else: ?>
                                                <?php echo e($index + 1); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td><code><?php echo e($stat->item_code); ?></code></td>
                                        <td><?php echo e($stat->item_name); ?></td>
                                        <td class="text-center"><?php echo e(number_format($stat->scrap_count)); ?></td>
                                        <td class="text-end"><?php echo e(number_format($stat->total_quantity)); ?></td>
                                        <td class="text-end text-danger"><?php echo e(number_format($stat->total_value, 2)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-filter"></i> Filters</h5>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('reports.scrap')); ?>">
                <div class="row">
                    <div class="col-md-3">
                        <label class="form-label">Date From</label>
                        <input type="date" name="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Date To</label>
                        <input type="date" name="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Item Code</label>
                        <input type="text" name="item_code" class="form-control" placeholder="Search item code..." value="<?php echo e(request('item_code')); ?>">
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2">
                            <i class="fas fa-search"></i> Filter
                        </button>
                        <a href="<?php echo e(route('reports.scrap')); ?>" class="btn btn-secondary">
                            <i class="fas fa-redo"></i> Reset
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-table"></i> Scrap Items Details</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Return No</th>
                            <th>Item Code</th>
                            <th>Item Name</th>
                            <th>Returned By</th>
                            <th class="text-center">Scrap Qty</th>
                            <th class="text-end">Unit Price</th>
                            <th class="text-end">Total Value</th>
                            <th>Scrap Reason</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $scrapItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($scrapItems->firstItem() + $index); ?></td>
                                <td><?php echo e($item->created_at->format('d M Y')); ?></td>
                                <td>
                                    <?php if($item->return): ?>
                                        <a href="<?php echo e(route('returns.show', $item->return_id)); ?>">
                                            <?php echo e($item->return->return_no ?? 'RET-' . str_pad($item->return_id, 6, '0', STR_PAD_LEFT)); ?>

                                        </a>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td><code><?php echo e($item->item_code); ?></code></td>
                                <td><?php echo e($item->item_name); ?></td>
                                <td><?php echo e($item->return->returnedBy->name ?? 'N/A'); ?></td>
                                <td class="text-center"><?php echo e(number_format($item->scrap_quantity)); ?></td>
                                <td class="text-end"><?php echo e(number_format($item->unit_price, 2)); ?></td>
                                <td class="text-end text-danger"><?php echo e(number_format($item->total_price, 2)); ?></td>
                                <td><?php echo e(Str::limit($item->scrap_reason ?? $item->remarks, 30)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="text-center py-4">
                                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">No scrap items found</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <div class="d-flex justify-content-between align-items-center mt-3">
                <div>
                    Showing <?php echo e($scrapItems->firstItem() ?? 0); ?> to <?php echo e($scrapItems->lastItem() ?? 0); ?> of <?php echo e($scrapItems->total()); ?> entries
                </div>
                <?php echo e($scrapItems->appends(request()->query())->links()); ?>

            </div>
        </div>
    </div>
</div>

<script>
    function exportToExcel() {
        // Get current URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        urlParams.set('export', 'excel');
        
        // Redirect with export parameter
        window.location.href = window.location.pathname + '?' + urlParams.toString();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\reports\scrap.blade.php ENDPATH**/ ?>