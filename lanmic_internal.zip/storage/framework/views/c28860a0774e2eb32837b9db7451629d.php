<?php $__env->startSection('title', 'Requisition Details'); ?>
<?php $__env->startSection('page-title', 'Requisition Details - Admin View'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.requisitions.index')); ?>">Requisition Approvals</a></li>
    <li class="breadcrumb-item active"><?php echo e($requisition->requisition_number); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Requisition Information</h3>
                <div class="card-tools">
                    <?php if($requisition->approve_status === 'pending'): ?>
                        <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#approveModal">
                            <i class="fas fa-check"></i> Approve
                        </button>
                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#rejectModal">
                            <i class="fas fa-times"></i> Reject
                        </button>
                    <?php elseif($requisition->approve_status === 'approved' && $requisition->clear_status !== 'cleared'): ?>
                        <a href="<?php echo e(route('admin.requisitions.issue-items', $requisition->id)); ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-box"></i> Issue Items
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if($requisition->approve_status === 'pending'): ?>
                <div class="alert alert-warning">
                    <i class="icon fas fa-exclamation-triangle"></i>
                    <strong>Action Required:</strong> This requisition is pending your approval.
                </div>
                <?php elseif($requisition->approve_status === 'approved' && $requisition->clear_status === 'pending'): ?>
                <div class="alert alert-info">
                    <i class="icon fas fa-info-circle"></i>
                    <strong>Approved:</strong> This requisition is approved. Items can be issued now.
                </div>
                <?php elseif($requisition->clear_status === 'cleared'): ?>
                <div class="alert alert-success">
                    <i class="icon fas fa-check-circle"></i>
                    <strong>Cleared:</strong> All items have been issued for this requisition.
                </div>
                <?php endif; ?>

                <div class="row mb-3">
                    <div class="col-md-4"><strong>Requisition Number:</strong></div>
                    <div class="col-md-8">
                        <span class="badge badge-secondary badge-lg"><?php echo e($requisition->requisition_number); ?></span>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Approval Status:</strong></div>
                    <div class="col-md-8">
                        <?php if($requisition->approve_status === 'pending'): ?>
                            <span class="badge badge-warning badge-lg">Pending</span>
                        <?php elseif($requisition->approve_status === 'approved'): ?>
                            <span class="badge badge-success badge-lg">Approved</span>
                        <?php else: ?>
                            <span class="badge badge-danger badge-lg">Rejected</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Clear Status:</strong></div>
                    <div class="col-md-8">
                        <?php if($requisition->clear_status === 'pending'): ?>
                            <span class="badge badge-warning">Pending</span>
                        <?php else: ?>
                            <span class="badge badge-success">Cleared</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Requested By:</strong></div>
                    <div class="col-md-8">
                        <?php echo e($requisition->user->name); ?>

                        <br><small class="text-muted"><?php echo e($requisition->user->email); ?></small>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Department:</strong></div>
                    <div class="col-md-8">
                        <?php echo e($requisition->department->name ?? '-'); ?>

                        <?php if($requisition->department && $requisition->department->short_code): ?>
                            <span class="badge badge-secondary"><?php echo e($requisition->department->short_code); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if($requisition->subDepartment): ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Sub-Department:</strong></div>
                    <div class="col-md-8">
                        <?php echo e($requisition->subDepartment->name); ?>

                        <?php if($requisition->subDepartment->short_code): ?>
                            <span class="badge badge-secondary"><?php echo e($requisition->subDepartment->short_code); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                <?php if($requisition->division): ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Division:</strong></div>
                    <div class="col-md-8">
                        <?php echo e($requisition->division->name); ?>

                        <?php if($requisition->division->short_code): ?>
                            <span class="badge badge-secondary"><?php echo e($requisition->division->short_code); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Purpose:</strong></div>
                    <div class="col-md-8"><?php echo e($requisition->purpose); ?></div>
                </div>
                <?php if($requisition->notes): ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Notes:</strong></div>
                    <div class="col-md-8"><?php echo e($requisition->notes); ?></div>
                </div>
                <?php endif; ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Created At:</strong></div>
                    <div class="col-md-8"><?php echo e($requisition->created_at->format('Y-m-d H:i:s')); ?></div>
                </div>
                <?php if($requisition->approve_status !== 'pending'): ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong><?php echo e($requisition->approve_status === 'approved' ? 'Approved' : 'Rejected'); ?> By:</strong></div>
                    <div class="col-md-8"><?php echo e($requisition->approvedBy->name ?? '-'); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4"><strong><?php echo e($requisition->approve_status === 'approved' ? 'Approved' : 'Rejected'); ?> At:</strong></div>
                    <div class="col-md-8"><?php echo e($requisition->approved_at ? $requisition->approved_at->format('Y-m-d H:i:s') : '-'); ?></div>
                </div>
                <?php endif; ?>
                <?php if($requisition->approve_status === 'rejected' && $requisition->rejection_reason): ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Rejection Reason:</strong></div>
                    <div class="col-md-8">
                        <div class="alert alert-danger"><?php echo e($requisition->rejection_reason); ?></div>
                    </div>
                </div>
                <?php endif; ?>
                <?php if($requisition->clear_status === 'cleared'): ?>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Cleared By:</strong></div>
                    <div class="col-md-8"><?php echo e($requisition->clearedBy->name ?? '-'); ?></div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4"><strong>Cleared At:</strong></div>
                    <div class="col-md-8"><?php echo e($requisition->cleared_at ? $requisition->cleared_at->format('Y-m-d H:i:s') : '-'); ?></div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Requisition Items</h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Item Code</th>
                            <th>Item Name</th>
                            <th>Category</th>
                            <th>Quantity</th>
                            <th>Issued</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $requisition->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php 
                            $issuedQty = $item->issuedItems->sum('issued_quantity');
                        ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><strong><?php echo e($item->item_code); ?></strong></td>
                            <td>
                                <?php echo e($item->item_name); ?>

                                <?php if($item->specifications): ?>
                                    <br><small class="text-muted"><i class="fas fa-info-circle"></i> <?php echo e($item->specifications); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item->item_category ?? '-'); ?></td>
                            <td><?php echo e($item->quantity); ?> <?php echo e($item->unit); ?></td>
                            <td>
                                <?php if($issuedQty > 0): ?>
                                    <span class="badge badge-<?php echo e($item->isFullyIssued() ? 'success' : 'info'); ?>">
                                        <?php echo e($issuedQty); ?> / <?php echo e($item->quantity); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="badge badge-secondary">0 / <?php echo e($item->quantity); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if($requisition->purchaseOrderItems->count() > 0): ?>
        <div class="card card-warning">
            <div class="card-header">
                <h3 class="card-title">Purchase Order Items (Not Available in Stock)</h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Item Code</th>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $requisition->purchaseOrderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $poItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><strong><?php echo e($poItem->item_code); ?></strong></td>
                            <td><?php echo e($poItem->item_name); ?></td>
                            <td><?php echo e($poItem->quantity); ?> <?php echo e($poItem->unit); ?></td>
                            <td>
                                <span class="badge badge-<?php echo e($poItem->status === 'pending' ? 'warning' : 'success'); ?>">
                                    <?php echo e(ucfirst($poItem->status)); ?>

                                </span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <?php if($requisition->issuedItems->count() > 0): ?>
        <div class="card card-success">
            <div class="card-header">
                <h3 class="card-title">Issued Items History</h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Item</th>
                            <th>Quantity Issued</th>
                            <th>Issued By</th>
                            <th>Issued At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $requisition->issuedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $issuedItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <strong><?php echo e($issuedItem->item_name); ?></strong>
                                <br><small class="text-muted"><?php echo e($issuedItem->item_code); ?></small>
                            </td>
                            <td><?php echo e($issuedItem->issued_quantity); ?> <?php echo e($issuedItem->unit); ?></td>
                            <td><?php echo e($issuedItem->issuedBy->name ?? '-'); ?></td>
                            <td><?php echo e($issuedItem->issued_at->format('Y-m-d H:i:s')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <div class="card-footer">
            <a href="<?php echo e(route('admin.requisitions.index')); ?>" class="btn btn-default">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
            <?php if($requisition->approve_status === 'pending'): ?>
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#approveModal">
                    <i class="fas fa-check"></i> Approve
                </button>
                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#rejectModal">
                    <i class="fas fa-times"></i> Reject
                </button>
            <?php elseif($requisition->approve_status === 'approved' && $requisition->clear_status !== 'cleared'): ?>
                <a href="<?php echo e(route('admin.requisitions.issue-items', $requisition->id)); ?>" class="btn btn-primary">
                    <i class="fas fa-box"></i> Issue Items
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Summary</h3>
            </div>
            <div class="card-body">
                <div class="info-box bg-light">
                    <div class="info-box-content">
                        <span class="info-box-text">Total Items</span>
                        <span class="info-box-number"><?php echo e($requisition->items->count()); ?></span>
                    </div>
                </div>
                <div class="info-box bg-light">
                    <div class="info-box-content">
                        <span class="info-box-text">Total Quantity</span>
                        <span class="info-box-number"><?php echo e($requisition->items->sum('quantity')); ?></span>
                    </div>
                </div>
                <?php if($requisition->approve_status === 'approved'): ?>
                <div class="info-box bg-light">
                    <div class="info-box-content">
                        <span class="info-box-text">Items Issued</span>
                        <span class="info-box-number text-success">
                            <?php echo e($requisition->items->filter(fn($item) => $item->isFullyIssued())->count()); ?> / <?php echo e($requisition->items->count()); ?>

                        </span>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Requester Information</h3>
            </div>
            <div class="card-body">
                <strong><i class="fas fa-user mr-1"></i> Name</strong>
                <p class="text-muted"><?php echo e($requisition->user->name); ?></p>
                <hr>
                <strong><i class="fas fa-envelope mr-1"></i> Email</strong>
                <p class="text-muted"><?php echo e($requisition->user->email); ?></p>
                <hr>
                <strong><i class="fas fa-user-tag mr-1"></i> Roles</strong>
                <p class="text-muted">
                    <?php $__currentLoopData = $requisition->user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge badge-info"><?php echo e($role->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
            </div>
        </div>
    </div>
</div>

<!-- Approve Modal -->
<div class="modal fade" id="approveModal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="<?php echo e(route('admin.requisitions.approve', $requisition->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header bg-success">
                    <h5 class="modal-title" id="approveModalLabel">Approve Requisition</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to approve this requisition?</p>
                    <p><strong>Requisition #:</strong> <?php echo e($requisition->requisition_number); ?></p>
                    <p><strong>Total Amount:</strong> Rs.<?php echo e(number_format($requisition->items->sum('total_price'), 2)); ?></p>
                    
                    <?php if($requisition->purchaseOrderItems->count() > 0): ?>
                        <div class="alert alert-warning">
                            <strong>Note:</strong> This requisition has <?php echo e($requisition->purchaseOrderItems->count()); ?> item(s) that require purchase orders.
                        </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check"></i> Approve
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1" role="dialog" aria-labelledby="rejectModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form action="<?php echo e(route('admin.requisitions.reject', $requisition->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header bg-danger">
                    <h5 class="modal-title" id="rejectModalLabel">Reject Requisition</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Please provide a reason for rejecting this requisition:</p>
                    <div class="form-group">
                        <label for="rejection_reason">Rejection Reason <span class="text-danger">*</span></label>
                        <textarea class="form-control" id="rejection_reason" name="rejection_reason" rows="4" required placeholder="Explain why this requisition is being rejected..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-times"></i> Reject
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\requisitions\show.blade.php ENDPATH**/ ?>