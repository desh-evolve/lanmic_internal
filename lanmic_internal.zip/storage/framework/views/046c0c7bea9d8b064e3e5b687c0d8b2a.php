<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active">Dashboard</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <!-- My Requisitions -->
        <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
                <div class="inner">
                    <h3><?php echo e(Auth::user()->requisitions()->count()); ?></h3>
                    <p>My Requisitions</p>
                </div>
                <div class="icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <a href="<?php echo e(route('requisitions.index')); ?>" class="small-box-footer">
                    More info <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <!-- Pending Requisitions -->
        <div class="col-lg-3 col-6">
            <div class="small-box bg-warning">
                <div class="inner">
                    <h3><?php echo e(Auth::user()->requisitions()->pending()->count()); ?></h3>
                    <p>Pending</p>
                </div>
                <div class="icon">
                    <i class="fas fa-clock"></i>
                </div>
                <a href="<?php echo e(route('requisitions.index')); ?>" class="small-box-footer">
                    More info <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <!-- Approved Requisitions -->
        <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
                <div class="inner">
                    <h3><?php echo e(Auth::user()->requisitions()->approved()->count()); ?></h3>
                    <p>Approved</p>
                </div>
                <div class="icon">
                    <i class="fas fa-check"></i>
                </div>
                <a href="<?php echo e(route('requisitions.index')); ?>" class="small-box-footer">
                    More info <i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>
        </div>

        <?php if(Auth::user()->hasRole('admin')): ?>
            <!-- Admin: Pending Approvals -->
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?php echo e(\App\Models\Requisition::pending()->count()); ?></h3>
                        <p>Need Approval</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-clipboard-check"></i>
                    </div>
                    <a href="<?php echo e(route('admin.requisitions.index')); ?>" class="small-box-footer">
                        More info <i class="fas fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        <?php else: ?>
            <!-- Regular User: Rejected -->
            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?php echo e(Auth::user()->requisitions()->rejected()->count()); ?></h3>
                        <p>Rejected</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-times"></i>
                    </div>
                    <a href="<?php echo e(route('requisitions.index')); ?>" class="small-box-footer">
                        More info <i class="fas fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Welcome, <?php echo e(Auth::user()->name); ?>!</h3>
                </div>
                <div class="card-body">
                    <p><strong>Email:</strong> <?php echo e(Auth::user()->email); ?></p>
                    <p><strong>Your Roles:</strong></p>
                    <?php $__currentLoopData = Auth::user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge badge-info mr-1"><?php echo e($role->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <p class="mt-3"><strong>Your Permissions:</strong></p>
                    <?php
                        $userPermissions = Auth::user()->roles->flatMap->permissions->unique('id');
                    ?>
                    <div class="row">
                        <?php $__currentLoopData = $userPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <small><i class="fas fa-check text-success"></i> <?php echo e($permission->name); ?></small>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Quick Links</h3>
                </div>
                <div class="card-body">
                    <div class="list-group">
                        <a href="<?php echo e(route('requisitions.create')); ?>" class="list-group-item list-group-item-action">
                            <i class="fas fa-plus-circle text-primary"></i> Create New Requisition
                        </a>
                        <a href="<?php echo e(route('requisitions.index')); ?>" class="list-group-item list-group-item-action">
                            <i class="fas fa-file-alt text-info"></i> My Requisitions
                        </a>

                        <?php if(Auth::user()->hasRole('admin')): ?>
                            <a href="<?php echo e(route('admin.requisitions.index')); ?>"
                                class="list-group-item list-group-item-action">
                                <i class="fas fa-clipboard-check text-warning"></i> Requisition Approvals
                            </a>
                        <?php endif; ?>

                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'view-users')): ?>
                            <a href="<?php echo e(route('users.index')); ?>" class="list-group-item list-group-item-action">
                                <i class="fas fa-users text-info"></i> Manage Users
                            </a>
                        <?php endif; ?>

                        <?php if (\Illuminate\Support\Facades\Blade::check('permission', 'view-roles')): ?>
                            <a href="<?php echo e(route('roles.index')); ?>" class="list-group-item list-group-item-action">
                                <i class="fas fa-user-tag text-success"></i> Manage Roles
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if(Auth::user()->hasRole('admin')): ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Recent Requisitions Needing Approval</h3>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Requisition #</th>
                                    <th>Requested By</th>
                                    <th>Department</th>
                                    <th>Items</th>
                                    <th>Total</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $pendingRequisitions = \App\Models\Requisition::pending()
                                        ->with(['user', 'department', 'items'])
                                        ->orderBy('created_at', 'desc')
                                        ->limit(5)
                                        ->get();
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $pendingRequisitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><strong><?php echo e($req->requisition_number); ?></strong></td>
                                        <td><?php echo e($req->user->name); ?></td>
                                        <td><?php echo e($req->department->name ?? '-'); ?></td>
                                        <td><span class="badge badge-info"><?php echo e($req->items->count()); ?></span></td>
                                        <td>Rs.<?php echo e(number_format($req->items->sum('total_price'), 2)); ?></td>
                                        <td><?php echo e($req->created_at->format('Y-m-d')); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.requisitions.show', $req->id)); ?>"
                                                class="btn btn-sm btn-primary">
                                                Review
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No pending requisitions</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($pendingRequisitions->count() > 0): ?>
                        <div class="card-footer">
                            <a href="<?php echo e(route('admin.requisitions.index')); ?>" class="btn btn-primary">View All
                                Requisitions</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\home.blade.php ENDPATH**/ ?>