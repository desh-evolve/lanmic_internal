<?php $__env->startSection('title', 'User Activity Report'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
    }
    .user-avatar-placeholder {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
    }
    .activity-badge {
        font-size: 0.75rem;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
    <div class="row mb-4">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="h3 mb-0">User Activity Report</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('reports.index')); ?>">Reports</a></li>
                            <li class="breadcrumb-item active">User Activity</li>
                        </ol>
                    </nav>
                </div>
                <div>
                    <button class="btn btn-success" onclick="exportToExcel()">
                        <i class="fas fa-file-excel"></i> Export Excel
                    </button>
                    <button class="btn btn-secondary" onclick="window.print()">
                        <i class="fas fa-print"></i> Print
                    </button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-filter"></i> Filters</h5>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('reports.user-activity')); ?>">
                <div class="row">
                    <div class="col-md-4">
                        <label class="form-label">Date From</label>
                        <input type="date" name="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Date To</label>
                        <input type="date" name="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>">
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2">
                            <i class="fas fa-search"></i> Filter
                        </button>
                        <a href="<?php echo e(route('reports.user-activity')); ?>" class="btn btn-secondary">
                            <i class="fas fa-redo"></i> Reset
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <div class="row mb-4">
        <?php
            $totalUsers = count($reportData);
            $totalRequisitions = collect($reportData)->sum('total_requisitions');
            $totalReturns = collect($reportData)->sum('total_returns');
            $activeUsers = collect($reportData)->filter(fn($d) => $d['total_requisitions'] > 0 || $d['total_returns'] > 0)->count();
        ?>
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body text-center">
                    <i class="fas fa-users fa-2x mb-2"></i>
                    <h3 class="mb-0"><?php echo e($totalUsers); ?></h3>
                    <small>Total Users</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body text-center">
                    <i class="fas fa-user-check fa-2x mb-2"></i>
                    <h3 class="mb-0"><?php echo e($activeUsers); ?></h3>
                    <small>Active Users</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body text-center">
                    <i class="fas fa-file-alt fa-2x mb-2"></i>
                    <h3 class="mb-0"><?php echo e($totalRequisitions); ?></h3>
                    <small>Total Requisitions</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-dark">
                <div class="card-body text-center">
                    <i class="fas fa-undo-alt fa-2x mb-2"></i>
                    <h3 class="mb-0"><?php echo e($totalReturns); ?></h3>
                    <small>Total Returns</small>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-trophy"></i> Top 5 Users by Requisitions</h5>
                </div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = collect($reportData)->sortByDesc('total_requisitions')->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div class="d-flex align-items-center">
                                    <span class="badge bg-<?php echo e($index == 0 ? 'warning' : ($index == 1 ? 'secondary' : 'dark')); ?> me-2">
                                        <?php echo e($index + 1); ?>

                                    </span>
                                    <div class="user-avatar-placeholder me-2">
                                        <?php echo e(strtoupper(substr($data['user']->name, 0, 1))); ?>

                                    </div>
                                    <div>
                                        <strong><?php echo e($data['user']->name); ?></strong>
                                        <br>
                                        <small class="text-muted"><?php echo e($data['user']->email); ?></small>
                                    </div>
                                </div>
                                <span class="badge bg-info rounded-pill"><?php echo e($data['total_requisitions']); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-header bg-warning text-dark">
                    <h5 class="mb-0"><i class="fas fa-undo"></i> Top 5 Users by Returns</h5>
                </div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = collect($reportData)->sortByDesc('total_returns')->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div class="d-flex align-items-center">
                                    <span class="badge bg-<?php echo e($index == 0 ? 'warning' : ($index == 1 ? 'secondary' : 'dark')); ?> me-2">
                                        <?php echo e($index + 1); ?>

                                    </span>
                                    <div class="user-avatar-placeholder me-2">
                                        <?php echo e(strtoupper(substr($data['user']->name, 0, 1))); ?>

                                    </div>
                                    <div>
                                        <strong><?php echo e($data['user']->name); ?></strong>
                                        <br>
                                        <small class="text-muted"><?php echo e($data['user']->email); ?></small>
                                    </div>
                                </div>
                                <span class="badge bg-warning text-dark rounded-pill"><?php echo e($data['total_returns']); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-table"></i> All Users Activity</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover" id="userActivityTable">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>User</th>
                            <th>Email</th>
                            <th>Role(s)</th>
                            <th class="text-center">Total Requisitions</th>
                            <th class="text-center">Pending Req.</th>
                            <th class="text-center">Approved Req.</th>
                            <th class="text-center">Total Returns</th>
                            <th class="text-center">Pending Returns</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="user-avatar-placeholder me-2">
                                            <?php echo e(strtoupper(substr($data['user']->name, 0, 1))); ?>

                                        </div>
                                        <strong><?php echo e($data['user']->name); ?></strong>
                                    </div>
                                </td>
                                <td><?php echo e($data['user']->email); ?></td>
                                <td>
                                    <?php if($data['user']->roles && $data['user']->roles->count() > 0): ?>
                                        <?php $__currentLoopData = $data['user']->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-secondary"><?php echo e($role->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <span class="text-muted">No role</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-primary rounded-pill"><?php echo e($data['total_requisitions']); ?></span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-warning text-dark rounded-pill"><?php echo e($data['pending_requisitions']); ?></span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-success rounded-pill"><?php echo e($data['approved_requisitions']); ?></span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-info rounded-pill"><?php echo e($data['total_returns']); ?></span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-danger rounded-pill"><?php echo e($data['pending_returns']); ?></span>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('reports.requisition-summary', ['user_id' => $data['user']->id])); ?>" 
                                       class="btn btn-sm btn-info" title="View Requisitions">
                                        <i class="fas fa-file-alt"></i>
                                    </a>
                                    <a href="<?php echo e(route('reports.returns-summary', ['user_id' => $data['user']->id])); ?>" 
                                       class="btn btn-sm btn-warning" title="View Returns">
                                        <i class="fas fa-undo-alt"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="text-center py-4">
                                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">No user data found</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    function exportToExcel() {
        // Get current URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        urlParams.set('export', 'excel');
        
        // Redirect with export parameter
        window.location.href = window.location.pathname + '?' + urlParams.toString();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\admin\reports\user-activity.blade.php ENDPATH**/ ?>