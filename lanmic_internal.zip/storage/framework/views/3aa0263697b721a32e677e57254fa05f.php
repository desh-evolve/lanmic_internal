<?php $__env->startSection('title', 'My Returns'); ?>
<?php $__env->startSection('page-title', 'My Returns'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item active">Returns</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Returns List</h3>
                <div class="card-tools">
                    <a href="<?php echo e(route('returns.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Create New Return
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th width="5%">#</th>
                                <th width="15%">Requisition</th>
                                <th width="15%">Returned At</th>
                                <th width="10%">Total Items</th>
                                <th width="10%">Total Qty</th>
                                <th width="10%">Same</th>
                                <th width="10%">Used</th>
                                <th width="10%">Status</th>
                                <th width="15%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $return): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration + ($returns->currentPage() - 1) * $returns->perPage()); ?></td>
                                <td>
                                    <strong><?php echo e($return->requisition->requisition_number); ?></strong><br>
                                    <small class="text-muted"><?php echo e($return->requisition->department->name ?? 'N/A'); ?></small>
                                </td>
                                <td><?php echo e($return->returned_at->format('Y-m-d H:i')); ?></td>
                                <td><span class="badge badge-info"><?php echo e($return->total_items); ?></span></td>
                                <td><span class="badge badge-primary"><?php echo e($return->total_quantity); ?></span></td>
                                <td><span class="badge badge-success"><?php echo e($return->same_items_count); ?></span></td>
                                <td><span class="badge badge-warning"><?php echo e($return->used_items_count); ?></span></td>
                                <td>
                                    <?php if($return->status === 'pending'): ?>
                                        <span class="badge badge-warning">Pending Approval</span>
                                    <?php elseif($return->status === 'approved'): ?>
                                        <span class="badge badge-success">Approved</span>
                                    <?php elseif($return->status === 'rejected'): ?>
                                        <span class="badge badge-danger">Rejected</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary"><?php echo e(ucfirst($return->status)); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('returns.show', $return->id)); ?>" 
                                       class="btn btn-sm btn-info" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    
                                    <?php if($return->status === 'pending'): ?>
                                    <form action="<?php echo e(route('returns.destroy', $return->id)); ?>" 
                                          method="POST" 
                                          class="d-inline"
                                          onsubmit="return confirm('Are you sure you want to delete this return?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted">
                                    No returns found. <a href="<?php echo e(route('returns.create')); ?>">Create your first return</a>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php if($returns->hasPages()): ?>
            <div class="card-footer clearfix">
                <?php echo e($returns->links()); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\DESH\PROJECTS\GitHub\lanmic_internal\resources\views\returns\index.blade.php ENDPATH**/ ?>