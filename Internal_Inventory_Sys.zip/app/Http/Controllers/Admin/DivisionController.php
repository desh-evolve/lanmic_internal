<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Division;
use App\Models\SubDepartment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class DivisionController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin');
        // $this->middleware('permission:view-divisions')->only(['index', 'show']);
        // $this->middleware('permission:create-divisions')->only(['create', 'store']);
        // $this->middleware('permission:edit-divisions')->only(['edit', 'update']);
        // $this->middleware('permission:delete-divisions')->only(['destroy']);
    }

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $divisions = Division::active()->withCount('subDepartments')->paginate(10);
        return view('admin.divisions.index', compact('divisions'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $subDepartments = SubDepartment::active()->get();
        return view('admin.divisions.create', compact('subDepartments'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255|unique:divisions',
            'short_code' => 'nullable|string|max:50|unique:divisions',
            'description' => 'nullable|string',
            'status' => 'string|max:11',
            'sub_departments' => 'nullable|array',
            'sub_departments.*' => 'exists:sub_departments,id',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $division = Division::create([
            'name' => $request->name,
            'short_code' => $request->short_code,
            'description' => $request->description,
            'status' => $request->status,
            'created_by' => Auth::id(),
            'updated_by' => Auth::id(),
        ]);

        if ($request->has('sub_departments')) {
            $division->subDepartments()->attach($request->sub_departments);
        }

        return redirect()->route('divisions.index')
            ->with('success', 'Division created successfully.');
    }

    /**
     * Display the specified resource.
     */
    // public function show(Division $division)
    // {
    //     // $division->load('subDepartments.departments');

    //     $division->load([
    //         'subDepartments' => function ($query) {
    //             $query->where('sub_departments.status', 'active')   // correct
    //                 ->where('division_sub_department.status', 'active'); // correct pivot
    //         },
    //         'departments' => function ($query) {
    //             $query->where('departments.status', 'active');
    //         },
    //     ]);
    //     return view('admin.divisions.show', compact('division'));
    // }

    public function show(Division $division)
    {
        $division->load([
            'subDepartments' => function ($q) {
                $q->where('sub_departments.status', 'active')
                    ->with(['departments' => function ($d) {
                        $d->where('departments.status', 'active')
                            ->where('department_sub_department.status', 'active');
                    }]);
            }
        ]);

        return view('admin.divisions.show', compact('division'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Division $division)
    {
        $subDepartments = SubDepartment::active()->get();
        $divisionSubDepartments = $division->subDepartments->pluck('id')->toArray();
        return view('admin.divisions.edit', compact('division', 'subDepartments', 'divisionSubDepartments'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Division $division)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255|unique:divisions,name,' . $division->id,
            'short_code' => 'nullable|string|max:50|unique:divisions,short_code,' . $division->id,
            'description' => 'nullable|string',
            'status' => 'string|max:11',
            'sub_departments' => 'nullable|array',
            'sub_departments.*' => 'exists:sub_departments,id',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        $division->update([
            'name' => $request->name,
            'short_code' => $request->short_code,
            'description' => $request->description,
            'status' => $request->status,
            'updated_by' => Auth::id(),
        ]);

        $division->subDepartments()->sync($request->sub_departments ?? []);

        return redirect()->route('divisions.index')
            ->with('success', 'Division updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Division $division)
    {
        $division->subDepartments()->detach();
        $division->delete();

        return redirect()->route('divisions.index')
            ->with('success', 'Division deleted successfully.');
    }
}
